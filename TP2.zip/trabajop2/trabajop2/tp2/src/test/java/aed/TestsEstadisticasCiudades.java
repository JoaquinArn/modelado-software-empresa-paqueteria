package aed;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.jupiter.api.BeforeEach;


public class TestsEstadisticasCiudades { 
    //Si bien los testeos los realiza estando "parados" en BestEffort, lo que esta
    // testeando es que EstadisticasCiudades tenga la funcionalidad buscada.
    int cantCiudades;                   
    EstadisticasCiudades estadisticas;
    BestEffort sistema;
    ArrayList<Integer> ciudadesMasRicas;
    ArrayList<Integer> ciudadesMasPobres;


    ArrayList <Integer> ordenar(ArrayList<Integer> lista) {
        int n = lista.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - 1 - i; j++) {
                if (lista.get(j) > lista.get(j + 1)) {
                    // Intercambia lista[j] y lista[j + 1]
                    int temp = lista.get(j);
                    lista.set(j, lista.get(j + 1)); 
                    lista.set(j + 1, temp);
                }
            }
        }
        return lista;
    }

    @BeforeEach
    void init(){

        cantCiudades = 7;
        estadisticas =  new EstadisticasCiudades(cantCiudades);
        Traslado [] listaTraslados = new Traslado[] {
            new Traslado(2, 0, 2, 100, 10),
            new Traslado(3, 1, 0, 100, 2),
            new Traslado(4, 0, 1, 250, 10),
            new Traslado(5, 2, 0, 100, 1),
        };
        sistema = new BestEffort(cantCiudades, listaTraslados);
        
        ciudadesMasRicas = new ArrayList<Integer>(1);
        ciudadesMasPobres = new ArrayList<Integer>(1);
    }

//Hay casos que involucran a EstadisticasCiudades que ya están testeados en BestEffort, por ejemplo, 
//el caso en el que no hay despachos; por lo que considera irrelevante testear lo mismo nuevamente.


    @Test
    void devuelveCiudadCorrectaIdUnico(){ 
        //Chequea que se realize bien la devolución al haber una única ciudad con la mayor ganancia/pérdida.
        sistema.despacharMasRedituables(4);
        ciudadesMasRicas.add(0);
        ciudadesMasPobres.add(1);
        ArrayList<Integer> resGanancia = sistema.ciudadesConMayorGanancia();
        assertTrue(ciudadesMasRicas.equals(resGanancia));
        assertTrue(ciudadesMasPobres.equals(sistema.ciudadesConMayorPerdida()));
        //Verifica que haya habido una buena contabilización, y un buen truncamiento en el promedio.
        assertEquals(137, sistema.gananciaPromedioPorTraslado()); 
    }  

    @Test
    void devuelveCiudadesVariasCorrectas(){
        //Testea que esté devolviendo todas las ciudades que tienen la ganancia/pérdida máxima.
        Traslado[] trasladoAEncolar = new Traslado[]{
            new Traslado(1, 2, 3, 250, 100)
        };
        sistema.registrarTraslados(trasladoAEncolar);
        sistema.despacharMasRedituables(5);
        ciudadesMasRicas.add(0);
        ciudadesMasRicas.add(2);
        ciudadesMasPobres.add(3);
        ciudadesMasPobres.add(1);
        assertTrue(ciudadesMasRicas.equals(sistema.ciudadesConMayorGanancia()));
        assertTrue(ciudadesMasPobres.equals(sistema.ciudadesConMayorPerdida()));
        //Examina que haya sacado bien el promedio.
        assertEquals(160, sistema.gananciaPromedioPorTraslado());
    }

    @Test
    void huboDespachosYAunAsiTodasIguales(){ 
        //Combinación de los testeos devuelveCiudadesVariasCorrectas y noHuboDespachos.
        //Se pretende que, luego de una gran cantidad despachos, el sistema haya contabilizado bien los montos.
        Traslado [] listaNuevaTraslados = new Traslado[] {  
            new Traslado(0, 0, 1, 100, 10), 
            new Traslado(1, 0, 2, 100, 20),
            new Traslado(2, 0, 3, 100, 10),
            new Traslado(3, 1, 0, 100, 20),
            new Traslado(4, 1, 2, 100, 10),
            new Traslado(5, 1, 3, 100, 20),
            new Traslado(6, 2, 0, 100, 10),
            new Traslado(7, 2, 1, 100, 20),
            new Traslado(8, 2, 3, 100, 20),
            new Traslado(9, 3, 0, 100, 20),
            new Traslado(10, 3, 1, 100, 20),
            new Traslado(11, 3, 2, 100, 20),
        };
        int ciudades = 4;
        BestEffort system = new BestEffort(ciudades, listaNuevaTraslados);
        system.despacharMasRedituables(12);
        ArrayList<Integer> ciudadesMasRicas = new ArrayList<Integer>(4);
        ArrayList<Integer> ciudadesMasPobres = new ArrayList<Integer>(4);
        ciudadesMasRicas.add(0);
        ciudadesMasRicas.add(1);
        ciudadesMasRicas.add(2);
        ciudadesMasRicas.add(3);
        ciudadesMasPobres.add(3);
        ciudadesMasPobres.add(0);
        ciudadesMasPobres.add(1);
        ciudadesMasPobres.add(2);
        ArrayList<Integer> res1 = new ArrayList<>();
        res1 = system.ciudadesConMayorGanancia();
        ArrayList<Integer> res2 = new ArrayList<>();
        res2 = system.ciudadesConMayorPerdida();
        //Testea que esté devolviendo todas las ciudades que tienen la ganancia/pérdida máxima; y chequea que el promedio sea el esperado.
        assertTrue(ciudadesMasRicas.equals(res1));
        assertTrue(ciudadesMasPobres.equals(res2));
        assertEquals(100, system.gananciaPromedioPorTraslado());

    }



    //En los siguientes tests, se quiere chequear que, tanto la devolución de las ciudades con mayor pérdida como las de mayor ganancia, 
    //se realizen correctamente, aún cuando las dos listas no tienen la misma dimensión/cantidad de ciudades.

    @Test
    void unicaCiudadConMayorPerdidaYVariasConMayorGanancia(){
        sistema.despacharMasAntiguos(2);
        ciudadesMasRicas.add(2);
        ciudadesMasRicas.add(1);
        ciudadesMasPobres.add(0);
        assertTrue(ciudadesMasRicas.equals(sistema.ciudadesConMayorGanancia()));
        assertTrue(ciudadesMasPobres.equals(sistema.ciudadesConMayorPerdida()));
        assertEquals(100, sistema.gananciaPromedioPorTraslado());
    }


    @Test
    void unicaCiudadConMayorGananciaYVariasConMayorPerdida(){
        sistema.registrarTraslados(new Traslado[] { new Traslado(10, 2, 0, 50, 100) });
        sistema.despacharMasAntiguos(5);
        ciudadesMasRicas.add(0);
        ciudadesMasPobres.add(1);
        ciudadesMasPobres.add(0);
        assertTrue(ciudadesMasRicas.equals(sistema.ciudadesConMayorGanancia()));
        assertTrue(ciudadesMasPobres.equals(sistema.ciudadesConMayorPerdida()));
        //Chequea que el promedio sea el correcto.
        assertEquals(120, sistema.gananciaPromedioPorTraslado()); 
    }


    @Test
    void testTodoIgualMenosId(){
        //Asegura que devuelva un array con los ID de ambas ciudades
        BestEffort sis = new BestEffort(3, new Traslado[] {
            new Traslado(1, 0, 1, 10, 10),
            new Traslado(2, 0, 1, 10, 10)
        });
        sis.despacharMasRedituables(2);

        //Resultado esperado
        ArrayList<Integer> esperadoGanancia = new ArrayList<>(Arrays.asList(0));
        ArrayList<Integer> esperadoPerdida = new ArrayList<>(Arrays.asList(1));
        ArrayList<Integer> gananciaActual = new ArrayList<>(sis.ciudadesConMayorGanancia());
        ArrayList<Integer> perdidaActual = new ArrayList<>(sis.ciudadesConMayorPerdida());

        //Ordena ambas listas antes de comparar
        ordenar(esperadoGanancia);
        ordenar(esperadoPerdida);
        ordenar(gananciaActual);
        ordenar(perdidaActual);

        //Comparación
        assertEquals(esperadoGanancia, gananciaActual);
        assertEquals(esperadoPerdida, perdidaActual);
        assertEquals(10, sis.gananciaPromedioPorTraslado());
    }

    @Test
    void testDosCiudadesConIgualGananciayPerdida(){
        //Asegura que devuelva un array con los ID de ambas ciudades
        BestEffort sis = new BestEffort(3, new Traslado[] {
            new Traslado(1, 0, 1, 100, 10),
            new Traslado(2, 1, 0, 100, 20)
        });
        sis.despacharMasRedituables(2);

        //Resultado esperado
        ArrayList<Integer> esperado = new ArrayList<>(Arrays.asList(1, 0));
        ArrayList<Integer> gananciaActual = new ArrayList<>(sis.ciudadesConMayorGanancia());
        ArrayList<Integer> perdidaActual = new ArrayList<>(sis.ciudadesConMayorPerdida());

        //Ordena ambas listas antes de comparar
        ordenar(esperado);
        ordenar(gananciaActual);
        ordenar(perdidaActual);

        //Comparación
        assertEquals(esperado, gananciaActual);
        assertEquals(esperado, perdidaActual);
        assertEquals(100, sis.gananciaPromedioPorTraslado());
        }
}
