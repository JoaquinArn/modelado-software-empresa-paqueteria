package aed;
import java.util.Comparator;
import java.util.ArrayList;

public class Heap {
    private ArrayList<TrasladoAmarrado> elems;
    private int tamaño;

    // Aplicamos el algoritmo de floyd. Este proceso tiene un tiempo de ejecución lineal porque, aunque cada operación de heapify tiene
    // un costo logarítmico en el peor caso, el número de nodos en los niveles más profundos del árbol es tan grande
    // que el costo total se distribuye de manera eficiente a lo largo de todos los nodos.
 

    public void array2Heap (TrasladoAmarrado[] traslados, Comparator<Traslado> comparador, String clave){ 
        this.tamaño = traslados.length;
        this.elems = new ArrayList <TrasladoAmarrado>();
            // Llenamos el heap con los trasladosAmarrados
        for (int i = 0; i < this.tamaño; i++) {
            Handle handleAmarreTraslado = traslados[i].handle;
            handleAmarreTraslado.modificarPosicion(traslados[i].traslado, i, clave);
            this.elems.add(traslados[i]);
        }
         // Aplicamos heapifyDown en todos los nodos no hoja (desde el último padre hacia arriba)
        for (int i = this.tamaño / 2 - 1; i >= 0; i--) {
            this.elems = heapifyDown(i, comparador, clave);  
        }
    }

    // Método para agregar un nuevo elemento al heap
    public void encolar(TrasladoAmarrado traslado, Comparator<Traslado> comparador, String clave) {         
        Handle handleAmarreTraslado = traslado.handle;
        handleAmarreTraslado.modificarPosicion(traslado.traslado, tamaño, clave);
        if (this.tamaño < this.elems.size()){
            this.elems.set(this.tamaño, traslado);
        }
        else{
            this.elems.add(traslado); // Agrega el elemento.
        }
        this.tamaño++;    
        heapifyUp(comparador, clave);
    }


    private void heapifyUp(Comparator<Traslado> comparador, String clave) {   
        int hijoActual = this.tamaño - 1;  // Comenzamos el proceso en el "ultimo hijo".
        
        boolean necesitaIntercambio = true;  // Utilizamos este booleano para poder cortar el while.

        while (hijoActual > 0 && necesitaIntercambio) {  // Si el hijoActual no es la raiz y todavia no chequeamos si necesita intercambio, entramos al loop.
            int padreActual = (hijoActual - 1) / 2;
            if (comparador.compare(this.elems.get(hijoActual).traslado, this.elems.get(padreActual).traslado) > 0) { // Chequeamos si el "hijoActual" es menor al padre, y si es asi, lo "swapeamos". 
                swap(padreActual, hijoActual, clave);
                hijoActual = padreActual;
            } 
            else {
                necesitaIntercambio = false;  // Detiene el ciclo cuando no es necesario intercambiar.
            }
        }
    }

    // Restablece la "propiedad"" de heap hacia abajo.
    private ArrayList<TrasladoAmarrado> heapifyDown(int indice, Comparator<Traslado> comparador, String clave) {
        while (!esHijo(this.tamaño, indice)) {

            int hijoIzq = 2 * indice + 1;
            int hijoDer = 2 * indice + 2;
            int mayor = hijoIzq; // Comenzamos planteando que el mas grande es el izquierdo y luego comparamos si es cierto o no y en base a eso, reemplazamos (hacemos swap).

            // Acá comparamos, y en caso de ser necesario, hacemos un swap
            if (hijoDer < this.tamaño && this.elems.get(hijoDer) != null){
                if (comparador.compare(this.elems.get(hijoDer).traslado, this.elems.get(hijoIzq).traslado) > 0) {
                    mayor = hijoDer;
                }
            }

            // Ahora comparamos el padre con el hijo "mayor" para decidir si es necesario hacer swap.
            if (this.elems.get(indice) == null || this.elems.get(indice).traslado == null || this.elems.get(mayor) == null ){
                break; // Acá no seria necesario hacer ningun cambio, es una salvaguarda.
            }
            else if (comparador.compare(this.elems.get(indice).traslado, this.elems.get(mayor).traslado) >= 0){
                break;
            }

              // Realizamos el intercambio.
            if (this.elems.get(mayor) != null){
                swap(indice, mayor, clave);
            }
            // Por ultimo, actualizamos el indice y continuamos el proceso.
            indice = mayor;
        }
        return this.elems;
    }


    // Método para intercambiar los elementos en las posiciones dadas dentro del heap.
    private void swap(int posPadre, int posHijo, String clave) {
        TrasladoAmarrado temp = this.elems.get(posPadre);
        temp.handle.modificarPosicion(temp.traslado, posHijo, clave);
        this.elems.get(posHijo).handle.modificarPosicion(this.elems.get(posHijo).traslado, posPadre, clave);
        this.elems.set(posPadre, this.elems.get(posHijo));
        this.elems.set(posHijo, temp);
    }

    // Extrae el elemento máximo del heap.
    public TrasladoAmarrado [] desencolar(int n, Comparator<Traslado> comparador, String clave) {
        if (n > tamaño){
            n = tamaño;
        }
        TrasladoAmarrado[] res = new TrasladoAmarrado[n];
        int i = 0;
        while (tamaño > 0 && i< n && i < this.elems.size()){
            TrasladoAmarrado trasladoEliminado = elems.get(0);
            res[i] = trasladoEliminado;
            elems.set(0, elems.get(tamaño - 1)); 
            this.elems.get(0).handle.modificarPosicion (this.elems.get(0).traslado, 0, clave);
            elems.set(tamaño - 1, null); // Establece la última posición como `null` para "eliminar" el último elemento.
        
        // Inicia el proceso de "heapificación hacia abajo" desde la raíz para restaurar la estructura del heap.
            tamaño --;
            int indice = 0;
            heapifyDown(indice, comparador, clave);
            i+= 1;
        }
        return res;
    }

    
    private boolean esHijo(int tamaño, int indice) {  // Si el índice es mayor que `tamaño/2 - 1`, significa que es un nodo hoja (hijo)
        
        return indice > tamaño / 2 - 1;
    }

    // Elimina segun un indice, y un comparador a especificar, un elemento del heap.
    public void eliminar(int indice, Comparator<Traslado> comparador, String clave){
        if (indice < 0 || this.elems.get(indice) == null) {
            return; 
        }
        elems.set(indice, elems.get(tamaño - 1)); 
        if (this.elems.get(indice) != null) {
            this.elems.get(indice).handle.modificarPosicion(this.elems.get(indice).traslado, indice, clave);
        }
        elems.set(tamaño - 1, null); // Establece la última posición como `null` para "eliminar" el último elemento
        
        // Inicia el proceso de "heapificación hacia abajo" desde la raíz para restaurar la estructura del heap
        heapifyDown(indice, comparador, clave);
        tamaño--;
    }
}
