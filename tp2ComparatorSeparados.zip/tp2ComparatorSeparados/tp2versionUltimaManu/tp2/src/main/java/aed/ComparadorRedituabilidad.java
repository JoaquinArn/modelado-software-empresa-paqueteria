package aed;
import java.util.Comparator;

public class ComparadorRedituabilidad implements Comparator<Traslado>{
    @Override

    public int compare(Traslado traslado1, Traslado traslado2) {
        int ganancia1 = traslado1.gananciaNeta; 
        int ganancia2 = traslado2.gananciaNeta;

        if (Integer.compare(ganancia1, ganancia2) == 0) { 
            int id1 = traslado1.id;
            int id2 = traslado2.id;        
            return Integer.compare(id2, id1);
            } // Si el primer imput es mayor el resultado es positivo, si es menor el resultado es negativo, si se empata utilizamos el ID como segundo criterio.
        else {  // Inicializamos los id's como variables y las comparamos.
            return Integer.compare(ganancia1, ganancia2); 
            }
        }
}
