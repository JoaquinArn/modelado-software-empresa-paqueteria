package aed;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

public class TestsHeap {
    @Test 
    void todosConMismaGananciaNeta(){
    Traslado[] listaTraslados = new Traslado[] {
                                            new Traslado(4, 0, 1, 100, 10),
                                            new Traslado(6, 0, 1, 100, 20),
                                            new Traslado(3, 3, 4, 100, 50),
                                            new Traslado(1, 4, 3, 100, 11),
                                            new Traslado(5, 1, 0, 100, 40),
                                            new Traslado(2, 1, 0, 100, 41),
                                            new Traslado(7, 6, 3, 100, 42)
                                        };
    TrasladoAmarrado [] trasladosConHandles = new TrasladoAmarrado[7];
    for (int i = 0; i < 7; i++){
        Handle handle = new Handle(listaTraslados[i]);
        trasladosConHandles[i] = new TrasladoAmarrado(listaTraslados[i], handle);
    }    
    Comparador comparador = new Comparador("redituabilidad");
    Heap heapRed = new Heap();
    heapRed.array2Heap(trasladosConHandles, comparador, "redito");
    TrasladoAmarrado[] devolucion = heapRed.desencolar(1, comparador, "redito");
    devolucion[0].handle.posiciones.first = 1;
    devolucion[0].traslado.id = 1;
    TrasladoAmarrado[] devolucion2 = heapRed.desencolar(1, comparador, "redito");
    devolucion2[0].handle.posiciones.first = 1;
    devolucion2[0].traslado.id = 2;
    TrasladoAmarrado[] devolucion3 = heapRed.desencolar(1, comparador, "redito");
    devolucion3[0].handle.posiciones.first = 1;
    devolucion3[0].traslado.id = 3;
    TrasladoAmarrado[] devolucion4 = heapRed.desencolar(1, comparador, "redito");
    devolucion4[0].handle.posiciones.first = 1;
    devolucion4[0].traslado.id = 4;
    TrasladoAmarrado[] devolucion5 = heapRed.desencolar(1, comparador, "redito");
    devolucion5[0].handle.posiciones.first = 1;
    devolucion5[0].traslado.id = 5;
    TrasladoAmarrado[] devolucion6 = heapRed.desencolar(1, comparador, "redito");
    devolucion6[0].handle.posiciones.first = 1;
    devolucion6[0].traslado.id = 6;
    TrasladoAmarrado[] devolucion7 = heapRed.desencolar(1, comparador, "redito");
    devolucion7[0].handle.posiciones.first = 1;
    devolucion7[0].traslado.id = 7;
    

    
    }
}