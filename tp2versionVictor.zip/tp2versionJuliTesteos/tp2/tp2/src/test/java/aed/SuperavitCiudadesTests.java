package aed;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

public class SuperavitCiudadesTests {
    private SuperavitCiudades<Integer> superavitCiudades;

    @BeforeEach
    void reiniciar() {
        superavitCiudades = new SuperavitCiudades<>(5);
    }

    @Test
    void testInicializacion() {
        // Verificar que el heap esté inicializado correctamente con todas las ganancias y pérdidas en 0
        for (int i = 0; i < 5; i++) {
            assertEquals(0, superavitCiudades.consultarMax(superavitCiudades));
        }
    }

    @Test
    void testModificarHeap() {
        // Modificar el heap y verificar que se actualicen correctamente las posiciones y valores
        superavitCiudades.modificarHeap(0, 1, 100);
        assertEquals(0, superavitCiudades.consultarMax(superavitCiudades)); // Ciudad 0 debería tener el mayor superávit

        superavitCiudades.modificarHeap(2, 0, 200);
        assertEquals(2, superavitCiudades.consultarMax(superavitCiudades)); // Ciudad 2 debería tener el mayor superávit

        superavitCiudades.modificarHeap(3, 2, 300);
        assertEquals(3, superavitCiudades.consultarMax(superavitCiudades)); // Ciudad 3 debería tener el mayor superávit

        superavitCiudades.modificarHeap(4, 3, 400);
        assertEquals(4, superavitCiudades.consultarMax(superavitCiudades)); // Ciudad 4 debería tener el mayor superávit
    }

    @Test
    void testHeapifyUp() {
        // Verificar que heapifyUp funcione correctamente
        superavitCiudades.modificarHeap(0, 1, 100);
        superavitCiudades.modificarHeap(2, 1, 50);
        assertEquals(0, superavitCiudades.consultarMax(superavitCiudades)); // Ciudad 0 debería tener el mayor superávit

        superavitCiudades.modificarHeap(3, 0, 150);
        assertEquals(3, superavitCiudades.consultarMax(superavitCiudades)); // Ciudad 3 debería tener el mayor superávit
    }

    @Test
    void testHeapifyDown() {
        // Verificar que heapifyDown funcione correctamente
        superavitCiudades.modificarHeap(1, 0, 100);
        superavitCiudades.modificarHeap(2, 0, 50);
        superavitCiudades.modificarHeap(3, 0, 150);
        superavitCiudades.modificarHeap(4, 0, 200);
        assertEquals(4, superavitCiudades.consultarMax(superavitCiudades)); // Ciudad 4 debería tener el mayor superávit

        superavitCiudades.modificarHeap(0, 4, 750);
        assertEquals(0, superavitCiudades.consultarMax(superavitCiudades)); // Ciudad 0 debería tener el mayor superávit
    }

    @Test
    void testConsultaMax() {
        // Verificar que consultarMax funcione correctamente
        assertEquals(0, superavitCiudades.consultarMax(superavitCiudades));

        superavitCiudades.modificarHeap(2, 1, 300);
        assertEquals(2, superavitCiudades.consultarMax(superavitCiudades)); // Ciudad 2 debería tener el mayor superávit
    }

    @Test
    void testModificacionesSimultaneas() {
        // Modificar múltiples ciudades simultáneamente y verificar el superávit
        superavitCiudades.modificarHeap(0, 1, 100);
        superavitCiudades.modificarHeap(2, 3, 200);
        superavitCiudades.modificarHeap(4, 0, 300);
        
        assertEquals(4, superavitCiudades.consultarMax(superavitCiudades)); // Ciudad 4 debería tener el mayor superávit

        superavitCiudades.modificarHeap(1, 4, 400);
        assertEquals(1, superavitCiudades.consultarMax(superavitCiudades)); // Ciudad 1 debería tener el mayor superávit

        superavitCiudades.modificarHeap(3, 1, 500);
        superavitCiudades.modificarHeap(4, 0, 600);
        assertEquals(4, superavitCiudades.consultarMax(superavitCiudades)); // Ciudad 3 debería tener el mayor superávit
    }

    @Test
    void testModificacionAleatoria() {
        // Realizar modificaciones aleatorias y verificar el estado del heap
        superavitCiudades.modificarHeap(1, 0, 300);
        assertEquals(1, superavitCiudades.consultarMax(superavitCiudades));

        superavitCiudades.modificarHeap(2, 1, 150);
        assertEquals(1, superavitCiudades.consultarMax(superavitCiudades));

        superavitCiudades.modificarHeap(3, 2, 400);
        assertEquals(3, superavitCiudades.consultarMax(superavitCiudades));

        superavitCiudades.modificarHeap(0, 3, 200);
        assertEquals(3, superavitCiudades.consultarMax(superavitCiudades));

        superavitCiudades.modificarHeap(4, 0, 500);
        assertEquals(4, superavitCiudades.consultarMax(superavitCiudades));
    }

    @Test
    void testManipulacionExtrema() {
        // Realizar modificaciones extremas y verificar la consistencia del heap
        superavitCiudades.modificarHeap(0, 1, 1000);
        assertEquals(0, superavitCiudades.consultarMax(superavitCiudades));

        superavitCiudades.modificarHeap(2, 0, 2000);
        assertEquals(2, superavitCiudades.consultarMax(superavitCiudades));

        superavitCiudades.modificarHeap(3, 2, 3000);
        assertEquals(3, superavitCiudades.consultarMax(superavitCiudades));

        superavitCiudades.modificarHeap(4, 3, 4000);
        assertEquals(4, superavitCiudades.consultarMax(superavitCiudades));

        superavitCiudades.modificarHeap(1, 4, 5000);
        assertEquals(1, superavitCiudades.consultarMax(superavitCiudades));

    }

    @Test
    void testMultiplesOperaciones() {
        // Realizar múltiples operaciones combinadas y verificar el estado del heap
        superavitCiudades.modificarHeap(0, 1, 500);
        superavitCiudades.modificarHeap(2, 3, 300);
        superavitCiudades.modificarHeap(4, 0, 700);

        assertEquals(4, superavitCiudades.consultarMax(superavitCiudades));

        superavitCiudades.modificarHeap(1, 4, 500);
        assertEquals(2, superavitCiudades.consultarMax(superavitCiudades));

        superavitCiudades.modificarHeap(3, 2, 400);
        assertEquals(4, superavitCiudades.consultarMax(superavitCiudades));

        superavitCiudades.modificarHeap(3, 4, 50); // Chequeo que el comparator determine por el id que ciudad tendra mas prioridad.
        assertEquals(3, superavitCiudades.consultarMax(superavitCiudades));

        superavitCiudades.modificarHeap(2, 4, 600);
        assertEquals(2, superavitCiudades.consultarMax(superavitCiudades));
    }
}

