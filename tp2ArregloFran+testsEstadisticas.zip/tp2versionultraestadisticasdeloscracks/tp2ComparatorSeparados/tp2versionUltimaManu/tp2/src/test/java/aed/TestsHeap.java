package aed;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

public class TestsHeap {

    TrasladosAmarrados trasladosConHandles;
    Heap heapRed;
    Heap heapAnt;
    ComparadorRedituabilidad comparadorRed;
    ComparadorAntiguedad comparadorAnt;



    @BeforeEach
    void init(){
        Traslado[] listaTraslados = new Traslado[] {
                    new Traslado(4, 0, 1, 100, 10),
                    new Traslado(6, 0, 1, 100, 20),
                    new Traslado(3, 3, 4, 100, 50),
                    new Traslado(1, 4, 3, 100, 11),
                    new Traslado(5, 1, 0, 100, 40),
                    new Traslado(2, 1, 0, 100, 41),
                    new Traslado(7, 6, 3, 100, 42)
                    };
        trasladosConHandles = new TrasladosAmarrados(listaTraslados);
        comparadorRed = new ComparadorRedituabilidad();
        comparadorAnt = new ComparadorAntiguedad();
    }


    @Test 
    void todosConMismaGananciaNeta(){ //chequea que desencole bien traslados con misma gananciaNeta en heap de redituabilidad
    heapRed = new Heap(trasladosConHandles, comparadorRed, "redito");
    TrasladosAmarrados devolucion = heapRed.desencolar(1, comparadorRed, "redito");
    assertEquals(0, devolucion.amarres.get(0).handle.posiciones.first); //chequeo funcionamiento correcto del handle
    assertEquals(1, devolucion.amarres.get(0).traslado.id);
    TrasladosAmarrados devolucion2 = heapRed.desencolar(1, comparadorRed, "redito");
    assertEquals(0, devolucion2.amarres.get(0).handle.posiciones.first); //chequeo funcionamiento correcto del handle
    assertEquals(2, devolucion2.amarres.get(0).traslado.id);
    TrasladosAmarrados devolucion3 = heapRed.desencolar(1, comparadorRed, "redito");
    assertEquals(0, devolucion3.amarres.get(0).handle.posiciones.first); //chequeo funcionamiento correcto del handle
    assertEquals(3, devolucion3.amarres.get(0).traslado.id);
    TrasladosAmarrados devolucion4 = heapRed.desencolar(1, comparadorRed, "redito");
    assertEquals(0, devolucion4.amarres.get(0).handle.posiciones.first); //chequeo funcionamiento correcto del handle
    assertEquals(4, devolucion4.amarres.get(0).traslado.id);
    TrasladosAmarrados devolucion5 = heapRed.desencolar(1, comparadorRed, "redito");
    assertEquals(0, devolucion5.amarres.get(0).handle.posiciones.first); //chequeo funcionamiento correcto del handle
    assertEquals(5, devolucion5.amarres.get(0).traslado.id);
    TrasladosAmarrados devolucion6 = heapRed.desencolar(1, comparadorRed, "redito");
    assertEquals(0, devolucion6.amarres.get(0).handle.posiciones.first); //chequeo funcionamiento correcto del handle
    assertEquals(6, devolucion6.amarres.get(0).traslado.id);
    TrasladosAmarrados devolucion7 = heapRed.desencolar(1, comparadorRed, "redito");
    assertEquals(0, devolucion7.amarres.get(0).handle.posiciones.first); //chequeo funcionamiento correcto del handle
    assertEquals(7, devolucion7.amarres.get(0).traslado.id);
    }

    @Test
    void crearYDevolverVacio(){ //chequeo que no se rompa el programa a la hora de querer hacer un heap con una lista vacía
        Traslado[] listaVacia = new Traslado[0];
        TrasladosAmarrados traslados = new TrasladosAmarrados(listaVacia);
        Heap heap = new Heap(traslados, comparadorRed , "redito");
        TrasladosAmarrados resultado = heap.desencolar(1, comparadorRed, "redito");
        TrasladosAmarrados esperado = new TrasladosAmarrados(listaVacia);
        assertEquals(esperado, resultado);
        assertTrue(esperado.amarres.equals(resultado.amarres)); //chequeo que el resultado sea el array con elemento nulo
    }

    @Test
    void buenEncoladoDeMaximos(){ //chequeo que haya un correcto heapifyUp a la hora de encolar elementos que presentan una prioridad mayor al resto
        heapAnt = new Heap(trasladosConHandles, comparadorAnt, "antiguedad");
        Traslado [] listaTrasladosAEncolar = new Traslado[]{
            new Traslado(10, 4, 1, 10, 1),
            new Traslado(11, 2, 4, 15, 2),
        };
        TrasladosAmarrados trasladosAEncolar = new TrasladosAmarrados(listaTrasladosAEncolar);
        for (int i = 0; i< trasladosAEncolar.amarres.size(); i++){
            heapAnt.encolar(trasladosAEncolar.amarres.get(i), comparadorAnt, "antiguedad");
            Traslado res = listaTrasladosAEncolar[i];
            assertEquals(res, heapAnt.desencolar(1, comparadorAnt, "antiguedad").amarres.get(0).traslado);
        }
    }

    @Test
    void buenEncoladoDeMinimos(){ //chequeo que haya un correcto heapifyUp a la hora de encolar elementos que presentan una prioridad menor al resto
        heapAnt = new Heap(trasladosConHandles, comparadorAnt, "antiguedad");
        Traslado [] listaTrasladosAEncolar = new Traslado[]{
            new Traslado(10, 4, 1, 10, 100),
            new Traslado(11, 2, 4, 15, 200),
        };
        TrasladosAmarrados trasladosAEncolar = new TrasladosAmarrados(listaTrasladosAEncolar);
        for (int i = 0; i< trasladosAEncolar.amarres.size(); i++){
            heapAnt.encolar(trasladosAEncolar.amarres.get(i), comparadorAnt, "antiguedad");
        }
        Traslado res1 = listaTrasladosAEncolar[0];
        Traslado res2 = listaTrasladosAEncolar[1];
        TrasladosAmarrados res = heapAnt.desencolar(9, comparadorAnt, "antiguedad");
        assertEquals(res1, res.amarres.get(7).traslado);
        assertEquals(res2, res.amarres.get(8).traslado);
    }

    @Test
    void desencoladoCorrecto(){ //en bestEffort ya se puede comprobar que también funciona con clave redituabilidad, sumado a que arriba vimos un caso particular del mismo
        heapAnt = new Heap(trasladosConHandles, comparadorAnt, "antiguedad");
        int [] esperado = new int [7];
        esperado[0] = 4;
        esperado[1] = 1;
        esperado[2] = 6;
        esperado[3] = 5;
        esperado[4] = 2;
        esperado[5] = 7;
        esperado[6] = 3;
        TrasladosAmarrados trasladosDesencolados = heapAnt.desencolar(7, comparadorAnt, "antiguedad");
        int [] res = new int[7];
        for (int i = 0; i < 7; i++){
            res[i] = trasladosDesencolados.amarres.get(i).traslado.id;
        }
        assertArrayEquals(esperado, res);
    }
}