package aed;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import org.junit.jupiter.api.BeforeEach;


public class TestsEstadisticasCiudades {
    int cantCiudades;
    EstadisticasCiudades estadisticas;
    BestEffort sistema;

    @BeforeEach
    void init(){
        //Reiniciamos los valores de las ciudades y traslados antes de cada test
        cantCiudades = 7;
        estadisticas =  new EstadisticasCiudades(cantCiudades);
        Traslado [] listaTraslados = new Traslado[] {
            new Traslado(2, 0, 2, 100, 10),
            new Traslado(3, 1, 0, 100, 20),
            new Traslado(4, 0, 1, 250, 10),
            new Traslado(5, 2, 0, 100, 20),
        };
        sistema = new BestEffort(cantCiudades, listaTraslados);
    }

    @Test
    void noHuboDespachos(){

        ArrayList<Integer> esperado = new ArrayList<Integer>(cantCiudades);
        for (int i = 0; i < cantCiudades; i++){
            esperado.add(i);
        }
        assertTrue(esperado.equals(sistema.ciudadesConMayorGanancia())) ;
        assertTrue(esperado.equals(sistema.ciudadesConMayorPerdida()));
    }

    @Test
    void devuelveCiudadCorrectaIdUnico(){
        sistema.despacharMasRedituables(4);
        ArrayList<Integer> ciudadMasRica = new ArrayList<Integer>(1);
        ArrayList<Integer> ciudadMasPobre = new ArrayList<Integer>(1);
        ciudadMasRica.add(0);
        ciudadMasPobre.add(1);
        ArrayList<Integer> resGanancia = sistema.ciudadesConMayorGanancia();
        assertTrue(ciudadMasRica.equals(resGanancia));
        assertTrue(ciudadMasPobre.equals(sistema.ciudadesConMayorPerdida()));
    }

    @Test
    void devuelveCiudadesVariasCorrectas(){
        Traslado[] trasladoAEncolar = new Traslado[]{
            new Traslado(1, 2, 3, 250, 100)
        };
        sistema.registrarTraslados(trasladoAEncolar);
        sistema.despacharMasRedituables(5);
        ArrayList<Integer> ciudadesMasRicas = new ArrayList<Integer>(2);
        ArrayList<Integer> ciudadesMasPobres = new ArrayList<Integer>(2);
        ciudadesMasRicas.add(0);
        ciudadesMasRicas.add(2);
        ciudadesMasPobres.add(3);
        ciudadesMasPobres.add(1);
        assertTrue(ciudadesMasRicas.equals(sistema.ciudadesConMayorGanancia()));
        assertTrue(ciudadesMasPobres.equals(sistema.ciudadesConMayorPerdida()));
    }

    @Test
    void huboDespachosYAunAsiTodasIguales(){
        Traslado [] listaNuevaTraslados = new Traslado[] {
            new Traslado(0, 0, 1, 100, 10),
            new Traslado(1, 0, 2, 100, 20),
            new Traslado(2, 0, 3, 100, 10),
            new Traslado(3, 1, 0, 100, 20),
            new Traslado(4, 1, 2, 100, 10),
            new Traslado(5, 1, 3, 100, 20),
            new Traslado(6, 2, 0, 100, 10),
            new Traslado(7, 2, 1, 100, 20),
            new Traslado(8, 2, 3, 100, 20),
            new Traslado(9, 3, 0, 100, 20),
            new Traslado(10, 3, 1, 100, 20),
            new Traslado(11, 3, 2, 100, 20),
        };
        int ciudades = 4;
        BestEffort system = new BestEffort(ciudades, listaNuevaTraslados);
        system.despacharMasRedituables(12);
        ArrayList<Integer> ciudadesMasRicas = new ArrayList<Integer>(4);
        ArrayList<Integer> ciudadesMasPobres = new ArrayList<Integer>(4);
        ciudadesMasRicas.add(0);
        ciudadesMasRicas.add(1);
        ciudadesMasRicas.add(2);
        ciudadesMasRicas.add(3);
        ciudadesMasPobres.add(3);
        ciudadesMasPobres.add(0);
        ciudadesMasPobres.add(1);
        ciudadesMasPobres.add(2);
        ArrayList<Integer> res1 = new ArrayList<>();
        res1 = system.ciudadesConMayorGanancia();
        ArrayList<Integer> res2 = new ArrayList<>();
        res2 = system.ciudadesConMayorPerdida();
        assertTrue(ciudadesMasRicas.equals(res1));
        assertTrue(ciudadesMasPobres.equals(res2));

    }
}
