package aed;

import java.util.ArrayList;

public class BestEffort {                                            
    //Completar atributos privados
    private SuperavitCiudades<int[]> superavitCiudades;
    private Heap redituabilidadTraslados;
    private Heap antiguedadTraslados;
    private EstadisticasCiudades estadisticas;




    //EJERCICIO 1
    // Al inicializar "BestEffort" se realizan una serie de asignaciones, que son O(1), se inicializa el heap "superavitCiudades" acotado por O(|C|); 
    // Y además la creacion de los heaps "redituabilidadTraslados" y "antiguedadTraslados" que tienen ambos complejidad O(|T|).
    // Complejidad final O(|C|+|T|)

    public BestEffort(int cantCiudades, Traslado[] traslados){
        // Inicialización de los atributos
        this.superavitCiudades = new SuperavitCiudades<int[]>(cantCiudades); //O(|C|)
        //Inicialización estadísticas
        this.estadisticas = new EstadisticasCiudades(cantCiudades);

        // Inicialización de los comparadores
        ComparadorRedituabilidad comparadorRedituabilidad = new ComparadorRedituabilidad();
        ComparadorAntiguedad comparadorAntiguedad = new ComparadorAntiguedad();

        TrasladosAmarrados arrayAHeap = new TrasladosAmarrados(traslados);

        // Nos armamos los heaps, a partir de los traslados con sus respectivos Handles.
        this.redituabilidadTraslados = new Heap(arrayAHeap, comparadorRedituabilidad, "redito"); //O(|T|)
        this.antiguedadTraslados = new Heap(arrayAHeap, comparadorAntiguedad, "antiguedad");    //O(|T|)
    } //Así: O(|C|) + O(|T|) + O(|T|) + O(|T|) + O(|T|) = O(|T|+|C|)
    



    //EJERCICIO 2
    // La complejidad requerida para este ejercicio es O(|traslados|log(|T|)). En el código, se ve de la siguiente forma:
    // Vamos a tener que ingresar al sistema ´n´ traslados, este n viene determinado por el largo de la lista que se nos da para registrar en el sistema.
    // Para cada uno de los traslados que van a ser ingresados, encolarlos en los Heaps de traslados nos lleva  O(log n) (para cada uno).
    // Nos queda entonces, como mencionamos al comienzo, O(|traslados| log(|T|)).

    public void registrarTraslados(Traslado[] traslados) {
        // Creamos dos comparadores para ordenar los traslados según los criterios de redituabilidad y antigüedad, que vamos a usar para encolarlos.
        ComparadorRedituabilidad comparadorRedituabilidad = new ComparadorRedituabilidad();
        ComparadorAntiguedad comparadorAntiguedad = new ComparadorAntiguedad();
    
        TrasladosAmarrados trasladosAlHeap = new TrasladosAmarrados(traslados);// Complejidad: O(|traslados|)
    
        // Encolamos cada TrasladoAmarrado (elementos de trasladosAlHeap) en dos heaps: uno por redituabilidad y otro por antigüedad.
        for (int k = 0; k < trasladosAlHeap.amarres.size(); k++) {       //|traslados| iteraciones   
            redituabilidadTraslados.encolar(trasladosAlHeap.amarres.get(k), comparadorRedituabilidad, "redito"); //O(log|T|)
            antiguedadTraslados.encolar(trasladosAlHeap.amarres.get(k), comparadorAntiguedad, "antiguedad");//O(log|T|)
        } // Complejidad: O(|traslados|log |T|)
    
    } //Complejidad : O(|traslados|log|T|) + O(|traslados|) = O(|traslados|log|T|)
    



    //EJERCICIO 3
    // Se requiere que la complejidad este acotada por O(n.(log |T|+ log |C|)). Esto se ve reflejado de la siguiente forma:
    // O(n log |T|) es desencolar ´n´ veces el máximo de mi Heap "redituabilidadTraslados".
    // O(n log |C|) es modificar la ganancia y la perdida ´n´ veces del heap "superávitCiudades". 
    // Cada traslado que se desencola de redituabilidadTraslados también se elimina de antiguedadTraslados utilizando la posición almacenada en su handle. Como nuestro handle almacena la posicion en antiguedadTraslados en la que se encuentra el traslado desencolado, buscarlo lleva O(1), y su eliminación toma O(n log|T|).
    // Como esto se repite n veces, la complejidad para esta operación es O(n log(|T|))
    // Finalmente tenemos que es O(n log(|T|) + n log(|C|)), o sacando Factor Común, O(n (log(|T|) + log(|C|)))

    public int[] despacharMasRedituables(int n) {
        // Creamos los comparadores para ordenar según redituabilidad y antigüedad.
        ComparadorRedituabilidad comparadorRedituabilidad = new ComparadorRedituabilidad();
        ComparadorAntiguedad comparadorAntiguedad = new ComparadorAntiguedad();

        // Desencolamos los n traslados más redituables.
        TrasladosAmarrados trasladosEliminados = redituabilidadTraslados.desencolar(n, comparadorRedituabilidad, "redito"); //O(n log |T|)
        int[] res = new int[trasladosEliminados.amarres.size()];
        for (int k = 0; k < trasladosEliminados.amarres.size(); k++) { 
            Traslado trasladoSinHandle = trasladosEliminados.amarres.get(k).traslado;
            Handle handleDelTraslado =  trasladosEliminados.amarres.get(k).handle;
            // Eliminamos el traslado del heap de antigüedad usando su handle.
            antiguedadTraslados.eliminar(handleDelTraslado.posiciones.second, comparadorAntiguedad, "antiguedad"); //O(log |T|)
            // Actualizamos los datos de superávit para la ciudad de origen y de pérdidas para la de destino; y lo que se halla en EstadisticasCiudades.
            superavitCiudades.modificarHeap(trasladoSinHandle.origen, trasladoSinHandle.destino, trasladoSinHandle.gananciaNeta); //O(log|C|)
            //Actualizamos todas las estadíticas según el parámetro necesario de traslado para cada una.
            estadisticas.actualizar(trasladoSinHandle);
            // Guardamos el ID del traslado eliminado.
            res[k] = trasladoSinHandle.id;
            
        } //Complejidad: O(n (log |C| + log |T|)). Nota: todo el resto de operaciones cuestan O(1)
        return res;

    }//Complejidad: O(n (log |C| + log |T|)) + O(n log|T|) = O(n (log |C| + log |T|))




    //EJERCICIO 4 
    // Al igual que en "despacharMasRedituables" la complejidad debe ser acotada por O(n (log(|T|) + log(|C|) ))
    // Se requiere que la complejidad este acotada por O(n.(log |T|+ log |C|)). Esto se ve reflejado de la siguiente forma:
    // O(n log |T|) es desencolar ´n´ veces el máximo de mi Heap "antiguedadTraslados".
    // O(n log |C|) es modificar la ganancia y la perdida ´n´ veces del heap "SuperávitCiudades". 
    // Cada traslado que se elimina de antiguedadTraslados también se elimina de redituabilidadTraslados utilizando la posición almacenada en su handle.
    // En un Heap, eliminar un elemento dado su posición tiene una complejidad de O(log(|T|)) (ajustando el Heap después de la eliminación).
    // Como esto se repite n veces, la complejidad para esta operación es O(n log(|T|))
    // Finalmente tenemos que es O(n log(|T|) + n log(|C|)) o sacando Factor Común O(n (log(|T|) + log(|C|)))

    public int[] despacharMasAntiguos(int n) {
            // Creamos comparadores para ordenar por redituabilidad y antigüedad.
            ComparadorRedituabilidad comparadorRedituabilidad = new ComparadorRedituabilidad();
            ComparadorAntiguedad comparadorAntiguedad = new ComparadorAntiguedad();
    
            // Desencolamos los n traslados más antiguos de la cola de antigüedad.
            TrasladosAmarrados trasladosEliminados = antiguedadTraslados.desencolar(n, comparadorAntiguedad, "antiguedad");
            int[] res = new int[trasladosEliminados.amarres.size()];
    
            // Procesamos cada traslado eliminado.
            for (int k = 0; k < trasladosEliminados.amarres.size(); k++) { 
                Traslado trasladoSinHandle = trasladosEliminados.amarres.get(k).traslado;
                Handle handleDelTraslado = trasladosEliminados.amarres.get(k).handle;
                // Eliminamos el traslado también del Heap de redituabilidad.
                redituabilidadTraslados.eliminar(handleDelTraslado.posiciones.first, comparadorRedituabilidad, "redito");
                // Actualizamos el superávit y pérdidas para las ciudades de origen y destino del traslado. Modificamos lo que se halla en EstadisticasCiudades.
                superavitCiudades.modificarHeap(trasladoSinHandle.origen, trasladoSinHandle.destino, trasladoSinHandle.gananciaNeta);
                //Actualizamos todas las estadíticas según el parámetro necesario de traslado para cada una.
                estadisticas.actualizar(trasladoSinHandle);
                // Guardamos el ID del traslado eliminado.
                res[k] = trasladoSinHandle.id;
                
            } //Complejidad: O(n (log |C| + log |T|)). Nota: todo el resto de operaciones cuestan O(1)
            return res;
            
    } //Complejidad: O(n (log |C| + log |T|)) + O(n log|T|) = O(n (log |C| + log |T|))

    


    //EJERCICIO 5
    // Es en O(1) ya que "consultarMax" es el primer valor del heap SuperavitCiudades.
    
    public int ciudadConMayorSuperavit(){
        return  superavitCiudades.consultarMax(superavitCiudades);
    }



    //EJERCICIO 6
    // Es en O(1) ya que únicamente devuelve una lista.
    
    public ArrayList<Integer> ciudadesConMayorGanancia(){
        return estadisticas.masLucrativas;
    }


    //EJERCICIO 7
    // Es en O(1) ya que únicamente devuelve una lista.
    
    public ArrayList<Integer> ciudadesConMayorPerdida(){
        return estadisticas.menosLucrativas;
    }



    //EJERCICIO 8
    // Es en O(1) ya que únicamente realiza una operación.
    
    public int gananciaPromedioPorTraslado(){
        if (estadisticas.amountAndProfitDespachos.first == 0){
            return 0;
        }
        else{
            return (estadisticas.amountAndProfitDespachos.second) / (estadisticas.amountAndProfitDespachos.first);
        }
    }
    
}
