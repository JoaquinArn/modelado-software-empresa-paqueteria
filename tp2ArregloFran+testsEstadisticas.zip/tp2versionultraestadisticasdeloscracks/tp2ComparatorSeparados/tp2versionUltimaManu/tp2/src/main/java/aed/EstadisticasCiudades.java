package aed;

import java.util.ArrayList;

public class EstadisticasCiudades {
    int[] ganancias;
    int[] perdidas;
    ArrayList<Integer> masLucrativas;
    ArrayList<Integer> menosLucrativas;
    int gananciaMaxima;
    int perdidaMaxima;
    Tupla amountAndProfitDespachos;
    
public EstadisticasCiudades(int cantCiudades){
    this.ganancias = new int[cantCiudades]; ;
    this.perdidas = new int[cantCiudades]; 
    this.masLucrativas = new ArrayList<>();
    this.menosLucrativas = new ArrayList<>();
    this.gananciaMaxima = 0;
    this.perdidaMaxima = 0;
    this.amountAndProfitDespachos =new Tupla(0,0);;
    for (int i = 0;i < ganancias.length; i++){
        masLucrativas.add(i);
        menosLucrativas.add(i);
    }
}
public void actualizar(Traslado traslado){
    ganancias[traslado.origen] += traslado.gananciaNeta;
    perdidas[traslado.destino] += traslado.gananciaNeta;
    amountAndProfitDespachos.first += 1;
    amountAndProfitDespachos.second += traslado.gananciaNeta;
    if (ganancias[traslado.origen] > gananciaMaxima) {
        masLucrativas.clear();
        masLucrativas.add(traslado.origen);
        gananciaMaxima= ganancias[traslado.origen];
    } 
    else if (ganancias[traslado.origen] == gananciaMaxima) {
        masLucrativas.add(traslado.origen);
    }

    if (perdidas[traslado.destino] > perdidaMaxima) {
        menosLucrativas.clear();
        menosLucrativas.add(traslado.destino);
        perdidaMaxima = perdidas[traslado.destino];
    } 
    else if (perdidas[traslado.destino] == perdidaMaxima) {
        menosLucrativas.add(traslado.destino);
    }
}

}


     
