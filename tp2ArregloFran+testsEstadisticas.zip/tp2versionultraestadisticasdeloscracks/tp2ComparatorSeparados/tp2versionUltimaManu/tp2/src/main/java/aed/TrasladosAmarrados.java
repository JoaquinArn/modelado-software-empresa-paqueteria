package aed;

import java.util.ArrayList;

public class TrasladosAmarrados {
    ArrayList<TrasladoAmarrado> amarres;

    public class TrasladoAmarrado{
        Traslado traslado;
        Handle handle;

        public TrasladoAmarrado(Traslado traslado, Handle handle){
            this.traslado = traslado;
            this.handle = handle;
        }
    }

    public TrasladosAmarrados(Traslado [] traslados){
        ArrayList<TrasladoAmarrado> amarres = new ArrayList<TrasladoAmarrado>(traslados.length);
        int i = 0;
        while (i < traslados.length && traslados[i] != null){
            Handle handle = new Handle(traslados[i]);
            TrasladoAmarrado amarre = new TrasladoAmarrado(traslados[i], handle);
            amarres.add(amarre);
            i = i + 1;
        }
        this.amarres = amarres;
    }

    @Override
    public boolean equals(Object obj){
        if (obj.getClass() != this.getClass()){
            return false;
        }
        else{
            TrasladosAmarrados objTraslado = (TrasladosAmarrados) obj; 
            return amarres.equals(objTraslado.amarres);
        }
    }
}
