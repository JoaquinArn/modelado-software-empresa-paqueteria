package aed;
import java.util.ArrayList;
import java.util.Comparator;

import aed.TrasladosAmarrados.TrasladoAmarrado;

public class Heap {
    private TrasladosAmarrados elems;
    private int tamaño;

    // Aplicamos el algoritmo de floyd. Este proceso tiene un tiempo de ejecución lineal porque, aunque cada operación de heapify tiene
    // un costo logarítmico en el peor caso, el número de nodos en los niveles más profundos del árbol es tan grande
    // que el costo total se distribuye de manera eficiente a lo largo de todos los nodos.
    
    public Heap (TrasladosAmarrados traslados, Comparator<Traslado> comparador, String clave){ 
        this.tamaño = traslados.amarres.size();
        Traslado[] creacionVacia = new Traslado[tamaño];
        this.elems = new TrasladosAmarrados(creacionVacia);

            // Llenamos el heap con los trasladosAmarrados
        for (int i = 0; i < this.tamaño; i++) {
            Handle handleAmarreTraslado = traslados.amarres.get(i).handle;
            handleAmarreTraslado.modificarPosicion(traslados.amarres.get(i).traslado, i, clave);
            this.elems.amarres.add(traslados.amarres.get(i));

        }
         // Aplicamos heapifyDown en todos los nodos no hoja (desde el último padre hacia arriba)
        for (int i = this.tamaño / 2 - 1; i >= 0; i--) {
            this.elems.amarres = heapifyDown(i, comparador, clave);  
        }
    }

    // Método para agregar un nuevo elemento al heap
    public void encolar(TrasladoAmarrado traslado, Comparator<Traslado> comparador, String clave) {         
        Handle handleAmarreTraslado = traslado.handle;
        handleAmarreTraslado.modificarPosicion(traslado.traslado, tamaño, clave);
        if (this.tamaño < this.elems.amarres.size()){
            this.elems.amarres.set(this.tamaño, traslado);
        }
        else{
            this.elems.amarres.add(traslado); // Agrega el elemento.
        }
        this.tamaño++;    
        heapifyUp(comparador, clave);
    }


    private void heapifyUp(Comparator<Traslado> comparador, String clave) {   
        int hijoActual = this.tamaño - 1;  // Comenzamos el proceso en el "ultimo hijo".
        
        boolean necesitaIntercambio = true;  // Utilizamos este booleano para poder cortar el while.

        while (hijoActual > 0 && necesitaIntercambio) {  // Si el hijoActual no es la raiz y todavia no chequeamos si necesita intercambio, entramos al loop.
            int padreActual = (hijoActual - 1) / 2;
            if (comparador.compare(this.elems.amarres.get(hijoActual).traslado, this.elems.amarres.get(padreActual).traslado) > 0) { // Chequeamos si el "hijoActual" es menor al padre, y si es asi, lo "swapeamos". 
                swap(padreActual, hijoActual, clave);
                hijoActual = padreActual;
            } 
            else {
                necesitaIntercambio = false;  // Detiene el ciclo cuando no es necesario intercambiar.
            }
        }
    }

    // Restablece la "propiedad"" de heap hacia abajo.
    private ArrayList<TrasladoAmarrado> heapifyDown(int indice, Comparator<Traslado> comparador, String clave) {
        while (!esHijo(this.tamaño, indice)) {

            int hijoIzq = 2 * indice + 1;
            int hijoDer = 2 * indice + 2;
            int mayor = hijoIzq; // Comenzamos planteando que el mas grande es el izquierdo y luego comparamos si es cierto o no y en base a eso, reemplazamos (hacemos swap).

            // Acá comparamos, y en caso de ser necesario, hacemos un swap
            if (hijoDer < this.tamaño && this.elems.amarres.get(hijoDer) != null){
                if (comparador.compare(this.elems.amarres.get(hijoDer).traslado, this.elems.amarres.get(hijoIzq).traslado) > 0) {
                    mayor = hijoDer;
                }
            }

            // Ahora comparamos el padre con el hijo "mayor" para decidir si es necesario hacer swap.
            if (this.elems.amarres.get(indice) == null || this.elems.amarres.get(indice).traslado == null || this.elems.amarres.get(mayor) == null ){
                break; // Acá no seria necesario hacer ningun cambio, es una salvaguarda.
            }
            else if (comparador.compare(this.elems.amarres.get(indice).traslado, this.elems.amarres.get(mayor).traslado) >= 0){
                break;
            }

              // Realizamos el intercambio.
            if (this.elems.amarres.get(mayor) != null){
                swap(indice, mayor, clave);
            }
            // Por ultimo, actualizamos el indice y continuamos el proceso.
            indice = mayor;
        }
        return this.elems.amarres;
    }


    // Método para intercambiar los elementos en las posiciones dadas dentro del heap.
    private void swap(int posPadre, int posHijo, String clave) {
        TrasladoAmarrado temp = this.elems.amarres.get(posPadre);
        temp.handle.modificarPosicion(temp.traslado, posHijo, clave);
        this.elems.amarres.get(posHijo).handle.modificarPosicion(this.elems.amarres.get(posHijo).traslado, posPadre, clave);
        this.elems.amarres.set(posPadre, this.elems.amarres.get(posHijo));
        this.elems.amarres.set(posHijo, temp);
    }

    // Extrae el elemento máximo del heap.
    public TrasladosAmarrados desencolar(int n, Comparator<Traslado> comparador, String clave) {
        if (n > tamaño){
            n = tamaño;
        }
        Traslado[] listaVacia = new Traslado[n]; 
        TrasladosAmarrados res = new TrasladosAmarrados(listaVacia);
        int i = 0;
        while (tamaño > 0 && i< n && i < this.elems.amarres.size()){
            TrasladoAmarrado trasladoEliminado = this.elems.amarres.get(0);
            res.amarres.add(trasladoEliminado);
            this.elems.amarres.set(0, elems.amarres.get(tamaño - 1)); 
            this.elems.amarres.get(0).handle.modificarPosicion (this.elems.amarres.get(0).traslado, 0, clave);
            elems.amarres.set(tamaño - 1, null); // Establece la última posición como `null` para "eliminar" el último elemento.
        
        // Inicia el proceso de "heapificación hacia abajo" desde la raíz para restaurar la estructura del heap.
            tamaño --;
            int indice = 0;
            heapifyDown(indice, comparador, clave);
            i+= 1;
        }
        return res;
    }

    
    private boolean esHijo(int tamaño, int indice) {  // Si el índice es mayor que `tamaño/2 - 1`, significa que es un nodo hoja (hijo)
        
        return indice > tamaño / 2 - 1;
    }

    // Elimina segun un indice, y un comparador a especificar, un elemento del heap.
    public void eliminar(int indice, Comparator<Traslado> comparador, String clave){
        if (indice < 0 || this.elems.amarres.get(indice) == null) {
            return; 
        }
        elems.amarres.set(indice, elems.amarres.get(tamaño - 1)); 
        if (this.elems.amarres.get(indice) != null) {
            this.elems.amarres.get(indice).handle.modificarPosicion(this.elems.amarres.get(indice).traslado, indice, clave);
        }
        this.elems.amarres.set(tamaño - 1, null); // Establece la última posición como `null` para "eliminar" el último elemento
        
        // Inicia el proceso de "heapificación hacia abajo" desde la raíz para restaurar la estructura del heap
        heapifyDown(indice, comparador, clave);
        tamaño--;
    }
}
