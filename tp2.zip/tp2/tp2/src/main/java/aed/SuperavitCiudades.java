package aed;
import java.util.Comparator;

public class SuperavitCiudades <T> {
    private Tupla [] elems;
    private int [] posiciones;

    private class superavitComparator implements Comparator<Tupla> {
        @Override
        public int compare(Tupla c1, Tupla c2){
            if (Integer.compare(c1.second, c2.second) == 0){
                if (c1.first < c2.first){
                    return 1;
                }
                else{
                    return -1;
                }
            } else{
                return Integer.compare(c1.second, c2.second);
            }
        }
    }

    public SuperavitCiudades(int cantCiudades) {
        Tupla[] heap = new Tupla[cantCiudades];
        int[] posicionesElems = new int[cantCiudades];
        
        for (int idCiudad = 0; idCiudad < cantCiudades; idCiudad++) {
            heap[idCiudad] = new Tupla(idCiudad, 0); // Inicializamos cada Tupla con id y superavit (0)
            posicionesElems[idCiudad] = idCiudad;
        }
        
        this.elems = heap;
        this.posiciones = posicionesElems;
        
    }

    public void modificarHeap(int id1, int id2, int monto){
        int posicionCiudadOrigen = this.posiciones[id1];
        int posicionCiudadDestino = this.posiciones[id2];
        this.elems[posicionCiudadOrigen].second += monto;
        this.elems[posicionCiudadDestino].second -= monto;
        heapifyDown(this.elems[posicionCiudadDestino]);
        heapifyUp(this.elems[posicionCiudadOrigen]);
    }

    private void heapifyUp(Tupla ciudad) {   
        int hijoActual = posiciones[ciudad.first];  // comenzamos el proceso en la ciudad a la que le sume
        
        boolean necesitaIntercambio = true;  // utilizamos este booleano para poder cortar el while

        while (hijoActual > 0 && necesitaIntercambio) {  // si el hijoActual no es la raiz y todavia no chequeamos si necesita intercambio, entramos al loop

            int padreActual = (hijoActual - 1) / 2;
            superavitComparator comparador = new superavitComparator();
            if (comparador.compare(this.elems[hijoActual], this.elems[padreActual]) > 0) { // chequeamos si el "hijoActual" es mayor al padre, y si es asi, lo swapeamos 
                int idPadre = this.elems[padreActual].first;
                int idHijo = this.elems[hijoActual].first;
                swap(padreActual, idPadre, hijoActual, idHijo);
                hijoActual = padreActual;
            } 
            else {
                necesitaIntercambio = false;  // detiene el ciclo cuando no es necesario intercambiar
            }
        }
}


    private void heapifyDown(Tupla ciudad) {
        int indice = posiciones[ciudad.first];
        int tamaño = posiciones.length;
        while (!esHijo(tamaño, indice)) {

            int hijoIzq = 2 * indice + 1;
            int hijoDer = 2 * indice + 2;
            int mayor = hijoIzq; // comenzamos planteando que el mas grande es el izquierdo y luego comparamos si es cierto o no y en base a eso, reemplazamos (hacemos swap)
            superavitComparator comparador = new superavitComparator();
            // acá comparamos, y en caso de ser necesario, hacemos un swap
            if (hijoDer < tamaño && comparador.compare(this.elems[hijoDer], this.elems[hijoIzq]) > 0) {
                mayor = hijoDer;
            }

            // ahora comparamos el padre con el hijo "mayor" para decidir si es necesario hacer swap
            if (comparador.compare(this.elems[indice], this.elems[mayor]) >= 0) {
                break; // acá no seria necesario hacer ningun cambio
            }

            int idIndice = this.elems[indice].first;
            int idMayor = this.elems[mayor].first;
            swap(indice, idIndice, mayor, idMayor);
        

            // por ultimo, actualizamos el indice y continuamos el proceso
            indice = mayor;
        }
}
private void swap(int posPadre, int idPadre, int posHijo, int idHijo) {
        
    Tupla temp = this.elems[posPadre];
    this.elems[posPadre] =  this.elems[posHijo];
    this.elems[posHijo] =  temp;
    this.posiciones[idPadre] = posHijo;
    this.posiciones[idHijo] = posPadre;
}
private boolean esHijo(int tamaño, int indice) {  // si el índice es mayor que `tamaño/2 - 1`, significa que es un nodo hoja (hijo)
        
    return indice > tamaño / 2 - 1;
}
public int consultarMax(SuperavitCiudades<T> heap){
    return heap.elems[0].first;
}

}
