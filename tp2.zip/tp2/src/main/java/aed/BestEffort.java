package aed;

import java.util.ArrayList;

public class BestEffort {
    //Completar atributos privados
    private SuperavitCiudades<int[]> superavitCiudades;
    private MaxHeap<int[]> redituabilidadTraslados;
    private MinHeap<int[]> antiguedadTraslados;
    private int[] gananciasCiudades;
    private ArrayList<Integer> ciudadesMasLucrativas;
    private int gananciaMaxima;
    private Tupla amountAndProfitDespachos;

    public BestEffort(int cantCiudades, Traslado[] traslados){
        // Inicialización de los atributos
        this.superavitCiudades = new SuperavitCiudades<int[]>(cantCiudades);
        this.redituabilidadTraslados = new MaxHeap<int[]>();
        this.antiguedadTraslados = new MinHeap<int[]>();
        this.gananciasCiudades = new int[cantCiudades]; 
        this.ciudadesMasLucrativas = new ArrayList<>();
        this.gananciaMaxima = 0;
        this.amountAndProfitDespachos = new Tupla(0,0);
        redituabilidadTraslados.array2Heap(traslados);
        antiguedadTraslados.array2Heap(traslados);
    }
    

    public void registrarTraslados(Traslado[] traslados){
        for (Traslado T: traslados){
        redituabilidadTraslados.encolar(redituabilidadTraslados, T.gananciaNeta, T.id);
        antiguedadTraslados.encolar(antiguedadTraslados, T.timestamp, T.id);
        superavitCiudades.modificarHeap(T.origen, T.gananciaNeta, T.destino, T.gananciaNeta, superavitCiudades);
        }
        
    }

    public int[] despacharMasRedituables(int n){
        // Implementar
        return null;
    }

    public int[] despacharMasAntiguos(int n){
        // Implementar
        return null;
    }

    public int ciudadConMayorSuperavit(){
        // Implementar
        return 0;
    }

    public ArrayList<Integer> ciudadesConMayorGanancia(){
        // Implementar
        return null;
    }

    public ArrayList<Integer> ciudadesConMayorPerdida(){
        // Implementar
        return null;
    }

    public int gananciaPromedioPorTraslado(){
        // Implementar
        return 0;
    }
    
}
