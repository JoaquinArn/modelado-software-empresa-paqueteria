package aed;

import java.util.ArrayList;

public class BestEffort {
    //Completar atributos privados
    private SuperavitCiudades<int[]> superavitCiudades;
    private MaxHeap<int[]> redituabilidadTraslados;
    private MinHeap<int[]> antiguedadTraslados;
    private int[] gananciasCiudades;
    private int[] perdidasCiudades;
    private ArrayList<Integer> ciudadesMasLucrativas;
    private ArrayList<Integer> ciudadesMenosLucrativas;
    private int gananciaMaxima;
    private int perdidaMaxima;
    private Tupla amountAndProfitDespachos;

    public BestEffort(int cantCiudades, Traslado[] traslados){
        // Inicialización de los atributos
        this.superavitCiudades = new SuperavitCiudades<int[]>(cantCiudades);
        this.redituabilidadTraslados = new MaxHeap<int[]>();
        this.antiguedadTraslados = new MinHeap<int[]>();
        this.gananciasCiudades = new int[cantCiudades]; 
        this.perdidasCiudades = new int[cantCiudades];
        this.ciudadesMasLucrativas = new ArrayList<>();
        this.ciudadesMenosLucrativas = new ArrayList<>();
        this.gananciaMaxima = 0;
        this.perdidaMaxima = 0;
        this.amountAndProfitDespachos = new Tupla(0,0);
        redituabilidadTraslados.array2Heap(traslados);
        antiguedadTraslados.array2Heap(traslados);
    }
    

    public void registrarTraslados(Traslado[] traslados){
        for (Traslado T: traslados){
        redituabilidadTraslados.encolar(redituabilidadTraslados, T);
        antiguedadTraslados.encolar(antiguedadTraslados, T);
    }
    
}

public int[] despacharMasRedituables(int n){
    int[] res = new int[n];
    Traslado [] trasladosEliminados = new Traslado[n];
    for (int i = 0; i <= n; i++){
        res[i] = redituabilidadTraslados.desencolarMax(redituabilidadTraslados);
    }
    for (int j = 0; j <= n; j++){
        trasladosEliminados[j] = antiguedadTraslados.eliminar(antiguedadTraslados, res[j]);
    }
    for (int k = 0; k <= n; k++){
        superavitCiudades.modificarHeap(trasladosEliminados[k].origen, trasladosEliminados[k].gananciaNeta, trasladosEliminados[k].destino, trasladosEliminados[k].gananciaNeta, superavitCiudades);
        gananciasCiudades[trasladosEliminados[k].origen] += trasladosEliminados[k].gananciaNeta;
        perdidasCiudades[trasladosEliminados[k].destino] += trasladosEliminados[k].gananciaNeta;
        amountAndProfitDespachos.second += trasladosEliminados[k].gananciaNeta;
        if (gananciasCiudades[trasladosEliminados[k].origen] > gananciaMaxima ){
            ciudadesMasLucrativas.clear();
            ciudadesMasLucrativas.add(trasladosEliminados[k].origen);
            gananciaMaxima = gananciasCiudades[trasladosEliminados[k].origen];
        }
        else if (gananciasCiudades[trasladosEliminados[k].origen] == gananciaMaxima){
            ciudadesMasLucrativas.add(trasladosEliminados[k].origen);
        }
        if (perdidasCiudades[trasladosEliminados[k].destino] > perdidaMaxima ){
            ciudadesMenosLucrativas.clear();
            ciudadesMenosLucrativas.add(trasladosEliminados[k].destino);
            perdidaMaxima = gananciasCiudades[trasladosEliminados[k].destino];
        }
        else if (perdidasCiudades[trasladosEliminados[k].destino] == perdidaMaxima){
            ciudadesMenosLucrativas.add(trasladosEliminados[k].destino);
        }

    };
    amountAndProfitDespachos.first += n;
    return res;
    }

    public int[] despacharMasAntiguos(int n){
        int[] res = new int[n];
        Traslado [] trasladosEliminados = new Traslado[n];
    for (int i = 0; i <= n; i++){
        res[i] = antiguedadTraslados.desencolarMin(antiguedadTraslados);
    }
    for (int j = 0; j <= n; j++){
        trasladosEliminados[j] = redituabilidadTraslados.eliminar(redituabilidadTraslados, res[j]);
    }
    for (int k = 0; k <= n; k++){
        superavitCiudades.modificarHeap(trasladosEliminados[k].origen, trasladosEliminados[k].gananciaNeta, trasladosEliminados[k].destino, trasladosEliminados[k].gananciaNeta, superavitCiudades);
        gananciasCiudades[trasladosEliminados[k].origen] += trasladosEliminados[k].gananciaNeta;
        perdidasCiudades[trasladosEliminados[k].destino] += trasladosEliminados[k].gananciaNeta;
        amountAndProfitDespachos.second += trasladosEliminados[k].gananciaNeta;
        if (gananciasCiudades[trasladosEliminados[k].origen] > gananciaMaxima ){
            ciudadesMasLucrativas.clear();
            ciudadesMasLucrativas.add(trasladosEliminados[k].origen);
            gananciaMaxima = gananciasCiudades[trasladosEliminados[k].origen];
        }
        else if (gananciasCiudades[trasladosEliminados[k].origen] == gananciaMaxima){
            ciudadesMasLucrativas.add(trasladosEliminados[k].origen);
        }
        if (perdidasCiudades[trasladosEliminados[k].destino] > perdidaMaxima ){
            ciudadesMenosLucrativas.clear();
            ciudadesMenosLucrativas.add(trasladosEliminados[k].destino);
            perdidaMaxima = gananciasCiudades[trasladosEliminados[k].destino];
        }
        else if (perdidasCiudades[trasladosEliminados[k].destino] == perdidaMaxima){
            ciudadesMenosLucrativas.add(trasladosEliminados[k].destino);
        }

    };
    amountAndProfitDespachos.first += n;
    return res;
    }

    public int ciudadConMayorSuperavit(){
        return  superavitCiudades.consultarMax(superavitCiudades);
    }

    public ArrayList<Integer> ciudadesConMayorGanancia(){
        return ciudadesMasLucrativas;
    }

    public ArrayList<Integer> ciudadesConMayorPerdida(){
        return ciudadesMenosLucrativas;
    }

    public int gananciaPromedioPorTraslado(){
        return amountAndProfitDespachos.second/amountAndProfitDespachos.first;
    }
    
}
