package aed;

import java.util.ArrayList;

public class BestEffort {
    //Completar atributos privados
    private SuperavitCiudades<int[]> superavitCiudades;
    private MaxHeap<int[]> redituabilidadTraslados;
    private MinHeap<int[]> antiguedadTraslados;
    private int[] gananciasCiudades;
    private int[] perdidasCiudades;
    private ArrayList<Integer> ciudadesMasLucrativas;
    private ArrayList<Integer> ciudadesMenosLucrativas;
    private int gananciaMaxima;
    private int perdidaMaxima;
    private Tupla amountAndProfitDespachos;


    //Al inicializar todas las asignaciones son O(1) salvo en superavitCiudades que es O(|C|) y además los llamados arra2Heap para redituabilidadTraslados y antiguedadTraslados tienen complejidad O(|T|).
    // Complejidad final O(|C|+|T|) 
    public BestEffort(int cantCiudades, Traslado[] traslados){
        // Inicialización de los atributos
        this.superavitCiudades = new SuperavitCiudades<int[]>(cantCiudades); //O(|C|)
        this.redituabilidadTraslados = new MaxHeap<int[]>();
        this.antiguedadTraslados = new MinHeap<int[]>();
        this.gananciasCiudades = new int[cantCiudades]; 
        this.perdidasCiudades = new int[cantCiudades];
        this.ciudadesMasLucrativas = new ArrayList<>();
        this.ciudadesMenosLucrativas = new ArrayList<>();
        this.gananciaMaxima = 0;
        this.perdidaMaxima = 0;
        this.amountAndProfitDespachos = new Tupla(0,0);
        redituabilidadTraslados.array2Heap(traslados); //O(|T|)
        antiguedadTraslados.array2Heap(traslados);    //O(|T|)
    }
    
    // La complejidad requerida para este ejercicio es O(|traslados|log(|T|)). En el codigo, se ve de la siguiente forma:
    // Vamos a tener que ingresar al sistema ´n´ traslados, este n viene determinado por el largo de la lista que se nos da para registrar en el sistema.
    // Para cada uno de los traslados que van a ser ingresados al sistema tenemos que recorrer el MaxHeap, lo cual nos lleva Log n (para cada uno).
    // Nos queda entonces, como mencionamos al comienzo, O(|traslados|. log(|T|)).
    public void registrarTraslados(Traslado[] traslados){
        for (Traslado T: traslados){
        redituabilidadTraslados.encolar(redituabilidadTraslados, T);
        antiguedadTraslados.encolar(antiguedadTraslados, T);
    }
    
}
// Se requiere que la complejidad este acotada por 0(n.(Log |T|+ Log |C|)). Esto se ve reflejado de la siguiente forma:
// O(n Log |T|) es desencolar ´n´ veces el máximo de mi MaxHeap "redituabilidadTraslados".
// O(n Log |C|) es modificar la ganancia y la perdida ´n´ veces del MaxHeap "superávitCiudades". 
// Por ultimo redefinimos el MinHeap "antiguedadTraslados", que nos lleva por el algoritmo de floyd (hablamos de su complejidad en el archivo "MaxHeap" y "MinHeap") O(n).
public int[] despacharMasRedituables(int n){
    Traslado [] trasladosEliminados = redituabilidadTraslados.desencolarMax(redituabilidadTraslados,n,antiguedadTraslados); // O(n Log |T|) + O(|T|-n)
    int [] res = new int[n];                                                               // Al pasar como dato el MinHeap "antigüedadTraslados" nos seguramos de "eliminar" 
    for (int k = 0; k <= n; k++){                                                        //los traslados ya despachados en O(| T|-n), usando nuevamente el algoritmo de Floyd 
        superavitCiudades.modificarHeap(trasladosEliminados[k].origen, trasladosEliminados[k].gananciaNeta, trasladosEliminados[k].destino, trasladosEliminados[k].gananciaNeta, superavitCiudades); //O(n Log |C|)
        gananciasCiudades[trasladosEliminados[k].origen] += trasladosEliminados[k].gananciaNeta;
        perdidasCiudades[trasladosEliminados[k].destino] += trasladosEliminados[k].gananciaNeta;
        amountAndProfitDespachos.second += trasladosEliminados[k].gananciaNeta;
        res[k] = trasladosEliminados[k].id;

        if (gananciasCiudades[trasladosEliminados[k].origen] > gananciaMaxima ){
            ciudadesMasLucrativas.clear();
            ciudadesMasLucrativas.add(trasladosEliminados[k].origen);
            gananciaMaxima = gananciasCiudades[trasladosEliminados[k].origen];
        }
        else if (gananciasCiudades[trasladosEliminados[k].origen] == gananciaMaxima){
            ciudadesMasLucrativas.add(trasladosEliminados[k].origen);
        }
        if (perdidasCiudades[trasladosEliminados[k].destino] > perdidaMaxima ){
            ciudadesMenosLucrativas.clear();
            ciudadesMenosLucrativas.add(trasladosEliminados[k].destino);
            perdidaMaxima = gananciasCiudades[trasladosEliminados[k].destino];
        }
        else if (perdidasCiudades[trasladosEliminados[k].destino] == perdidaMaxima){
            ciudadesMenosLucrativas.add(trasladosEliminados[k].destino);
        }
    };
    amountAndProfitDespachos.first += n;
    return res;
    }



    // Al igual que en "despacharMasRedituables" la complejidad debe ser acotada por O(n (Log(|T|) +Log(|C|) ))
    // O(n Log |T|) es desencolar ´n´ veces el máximo de mi MaxHeap "antiguedadTraslados".
    // O(n Log |C|) es modificar la ganancia y la perdida ´n´ veces del MaxHeap "superávitCiudades".
    // Por ultimo redefinimos el MaxHeap "redituabilidadTraslados", que nos lleva por el algoritmo de floyd (hablamos de su complejidad en el archivo "MaxHeap" y "MinHeap") O(n).
    public int[] despacharMasAntiguos(int n){
        Traslado [] trasladosEliminados =  antiguedadTraslados.desencolarMin(antiguedadTraslados,n,redituabilidadTraslados); // O(n Log |T|) + O(|T|-n)
        int[] res = new int[n];                                                                 // Al pasar como dato el MaxHeap "redituabilidadTraslados" nos seguramos de "eliminar" 
    for (int k = 0; k <= n; k++){                                                               //los traslados ya despachados en O(| T|-n), usando nuevamente el algoritmo de Floyd 
        superavitCiudades.modificarHeap(trasladosEliminados[k].origen, trasladosEliminados[k].gananciaNeta, trasladosEliminados[k].destino, trasladosEliminados[k].gananciaNeta, superavitCiudades);//O(n Log |C|)
        gananciasCiudades[trasladosEliminados[k].origen] += trasladosEliminados[k].gananciaNeta;
        perdidasCiudades[trasladosEliminados[k].destino] += trasladosEliminados[k].gananciaNeta;
        amountAndProfitDespachos.second += trasladosEliminados[k].gananciaNeta;
        res[k] = trasladosEliminados[k].id;
        if (gananciasCiudades[trasladosEliminados[k].origen] > gananciaMaxima ){
            ciudadesMasLucrativas.clear();
            ciudadesMasLucrativas.add(trasladosEliminados[k].origen);
            gananciaMaxima = gananciasCiudades[trasladosEliminados[k].origen];
        }
        else if (gananciasCiudades[trasladosEliminados[k].origen] == gananciaMaxima){
            ciudadesMasLucrativas.add(trasladosEliminados[k].origen);
        }
        if (perdidasCiudades[trasladosEliminados[k].destino] > perdidaMaxima ){
            ciudadesMenosLucrativas.clear();
            ciudadesMenosLucrativas.add(trasladosEliminados[k].destino);
            perdidaMaxima = gananciasCiudades[trasladosEliminados[k].destino];
        }
        else if (perdidasCiudades[trasladosEliminados[k].destino] == perdidaMaxima){
            ciudadesMenosLucrativas.add(trasladosEliminados[k].destino);
        }

    };
    amountAndProfitDespachos.first += n;
    return res;
    }

    public int ciudadConMayorSuperavit(){
        return  superavitCiudades.consultarMax(superavitCiudades);
    }


    // Es en O(1) ya que returnea el primer elemento de una lista
    public ArrayList<Integer> ciudadesConMayorGanancia(){
        return ciudadesMasLucrativas;
    }

    public ArrayList<Integer> ciudadesConMayorPerdida(){
        return ciudadesMenosLucrativas;
    }

    public int gananciaPromedioPorTraslado(){
        return amountAndProfitDespachos.second/amountAndProfitDespachos.first;
    }
    
}
