package aed;

public class TrasaldoHandle {
    Traslado t;
    Tupla handle;
    public TrasaldoHandle(Traslado t, Tupla handle){
        this.t = t;
        this.handle.first = 0;
        this.handle.second = 0;

    }
    
}
