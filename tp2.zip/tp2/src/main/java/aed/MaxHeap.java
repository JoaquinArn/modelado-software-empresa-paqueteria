package aed;

import java.util.ArrayList;
import java.util.Comparator;

public class MaxHeap<T>{
    private ArrayList<Traslado> elems;
    private int tamaño;


    private class RedituabilidadComparator implements Comparator<Traslado> {

        @Override

        public int compare(Traslado rediTraslado1, Traslado rediTraslado2) {

            int ganancia1 = rediTraslado1.gananciaNeta; 
            int ganancia2 = rediTraslado2.gananciaNeta;
    
            if (ganancia1 > ganancia2) {         // si el primer imput es mayor el resultado es 1, si es menor el resultado es -1, si se empata utilizamos el ID como segundo criterio
                return 1;
            } else if (ganancia1 < ganancia2) {
                return -1;



            } else {  // inicializamos los id's como variables y las comparamos 
                int id1 = rediTraslado1.id;
                int id2 = rediTraslado2.id;
    
                return Integer.compare(id1, id2); 
            }
        }
}
    
  

    // Nos cuesta O(1) ya es una asignación, y crear un Array vacío.
    public MaxHeap() { // constructor del heap vacio
        this.elems = new ArrayList<>();
        this.tamaño = 0;
    }

    // Este proceso tiene un tiempo de ejecución lineal porque, aunque cada operación de heapify tiene
    // un costo logarítmico en el peor caso, el número de nodos en los niveles más profundos del árbol es tan grande
    // que el costo total se distribuye de manera eficiente a lo largo de todos los nodos.


    public void array2Heap (Traslado[] traslados){ // algoritmo de floyd para armarnos el heap con la informacion de los traslados. 
       
        this.tamaño = traslados.length;
        this.elems = new ArrayList <>();
        for (int i = 0; i < this.tamaño; i++) {
            this.elems.add(traslados[i]);
    }
        for (int i = this.tamaño / 2 - 1; i >= 0; i--) {

        this.elems = heapifyDown(this, i);  
    }



    }
    public void array2HeapAux (ArrayList<Traslado> traslados){ 

        this.tamaño = traslados.size();
        this.elems = new ArrayList <>();
        for (int i = 0; i < this.tamaño; i++) {
            this.elems.add(traslados.get(i));
    }
        for (int i = this.tamaño / 2 - 1; i >= 0; i--) {
    
        this.elems = heapifyDown(this, i);
    }

}
    // Nos cuesta O(Log(n)) ya que tenemos que llamar a heapifyUp para poder agregar el elemento (traslado), y heapifyUp cuesta O(Log n).
    public void encolar(MaxHeap<T> heap, Traslado traslado) { 

        heap.elems.add(traslado); //agrega el elemento
        heapifyUp(heap);
        heap.tamaño++;    
}

    // Este metodo esta acotado por O(Log(n)) a continuación explicamos porque:
    // En cada iteración del bucle, el nodo asciende una posición en el árbol (se mueve hacia su padre).
    // En el peor de los casos, el nodo tiene que ascender desde el último nivel hasta la raíz, lo que implica un número de 
    // iteraciones proporcional a la altura del árbol.
    // La altura de un árbol binario completo es log⁡(n), donde n es el número de nodos en el heap.
    private void heapifyUp(MaxHeap<T> heap) {   
        int hijoActual = heap.tamaño - 1;  // comenzamos el proceso en el "ultimo hijo"
        
        boolean necesitaIntercambio = true;  // utilizamos este booleano para poder cortar el while

        RedituabilidadComparator comparator = new RedituabilidadComparator();

        while (hijoActual > 0 && necesitaIntercambio) {  // si el hijoActual no es la raiz y todavia no chequeamos si necesita intercambio, entramos al loop

            int padreActual = (hijoActual - 1) / 2;

            if (comparator.compare(heap.elems.get(hijoActual), heap.elems.get(padreActual)) > 0) { // chequeamos si el "hijoActual" es mayor al padre, y si es asi, lo swapeamos 

                swap(heap,padreActual, hijoActual);
                hijoActual = padreActual;
            } else {
                necesitaIntercambio = false;  // detiene el ciclo cuando no es necesario intercambiar
            }
        }
}

    //
    private ArrayList<Traslado> heapifyDown(MaxHeap<T> heap, int indice) {

        while (!esHijo(heap.tamaño, indice)) {

            int hijoIzq = 2 * indice + 1;
            int hijoDer = 2 * indice + 2;
            int mayor = hijoIzq; // comenzamos planteando que el mas grande es el izquierdo y luego comparamos si es cierto o no y en base a eso, reemplazamos (hacemos swap)
            RedituabilidadComparator comparator = new RedituabilidadComparator();
            // acá comparamos, y en caso de ser necesario, hacemos un swap
            if (hijoDer < heap.tamaño &&
                comparator.compare(heap.elems.get(hijoDer), heap.elems.get(hijoIzq)) > 0) {
                mayor = hijoDer;
            }

            // ahora comparamos el padre con el hijo "mayor" para decidir si es necesario hacer swap
            if (comparator.compare(heap.elems.get(indice), heap.elems.get(mayor)) >= 0) {
                break; // acá no seria necesario hacer ningun cambio
            }

            // intercambio 
            swap(heap, indice, mayor);
            // por ultimo, actualizamos el indice y continuamos el proceso
            indice = mayor;
        }
        return heap.elems;
}


    // método para intercambiar los elementos en las posiciones dadas dentro del heap
    private void swap(MaxHeap<T> heap, int posPadre, int posHijo) {
        
        Traslado temp = heap.elems.get(posPadre);
      
        heap.elems.set(posPadre, heap.elems.get(posHijo));
        
        heap.elems.set(posHijo, temp);
}

    // extrae el elemento máximo del heap
    public Traslado [] desencolarMax(MaxHeap<T> heap, int n, MinHeap<T> antiguedadTraslados) {
        Traslado[] res = new Traslado[n];
        int i = 0;
        while (i < n){
            Traslado trasladoEliminado = elems.get(0);
            res[i] = trasladoEliminado;
       
            elems.set(0, elems.get(tamaño - 1)); // establece la última posición como `null` para "eliminar" el último elemento
        
            elems.set(tamaño - 1, null); // inicia el proceso de "heapificación hacia abajo" desde la raíz para restaurar la estructura del heap
        
            int indice = 0;
            heapifyDown(heap,indice);
      
            tamaño--;
            i++;
        }
        antiguedadTraslados.array2HeapAux(heap.elems);
        return res;
}

    
    private boolean esHijo(int tamaño, int indice) {  // si el índice es mayor que `tamaño/2 - 1`, significa que es un nodo hoja (hijo)
        
        return indice > tamaño / 2 - 1;
}

}

