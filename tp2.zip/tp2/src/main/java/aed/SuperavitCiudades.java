package aed;
import java.util.Comparator;

public class SuperavitCiudades <T> {
    private Tupla [] elems;
    private int [] posiciones;

    private class superavitComparator implements Comparator<Tupla> {
        @Override
        public int compare(Tupla c1, Tupla c2){
            if (Integer.compare(c1.second, c2.second) == 0){
                return Integer.compare(c1.first, c2.first);
            } else{
                return Integer.compare(c1.second, c2.second);
            }
        }
    }

    public SuperavitCiudades(int cantCiudades) {
        Tupla[] heap = new Tupla[cantCiudades];
        int[] posicionesElems = new int[cantCiudades];
        
        for (int idCiudad = 0; idCiudad < cantCiudades; idCiudad++) {
            heap[idCiudad] = new Tupla(idCiudad, 0); // Inicializamos cada Tupla con id y superavit (0)
            posicionesElems[idCiudad] = idCiudad;
        }
        
        this.elems = heap;
        this.posiciones = posicionesElems;
        
    }

    public void modificarHeap(int id1, int ganancia, int id2, int perdida, SuperavitCiudades<T> heap){
        int posicionCiudadOrigen = this.posiciones[id1];
        int posicionCiudadDestino = this.posiciones[id2];
        heap.elems[posicionCiudadOrigen].second += ganancia;
        heap.elems[posicionCiudadDestino].second -= perdida;
        heapifyUp(heap,this.elems[posicionCiudadOrigen]);
        heapifyDown(heap,this.elems[posicionCiudadDestino]);
    }

    private void heapifyUp(SuperavitCiudades<T> heap, Tupla ciudad) {   
        int hijoActual = posiciones.length - posiciones[ciudad.first];  // comenzamos el proceso en la ciudad a la que le sume
        
        boolean necesitaIntercambio = true;  // utilizamos este booleano para poder cortar el while

        while (hijoActual > 0 && necesitaIntercambio) {  // si el hijoActual no es la raiz y todavia no chequeamos si necesita intercambio, entramos al loop

            int padreActual = (hijoActual - 1) / 2;

            if (new superavitComparator().compare(heap.elems[hijoActual], heap.elems[padreActual]) > 0) { // chequeamos si el "hijoActual" es mayor al padre, y si es asi, lo swapeamos 

                swap(heap,padreActual, hijoActual);
                hijoActual = padreActual;
            } else {
                necesitaIntercambio = false;  // detiene el ciclo cuando no es necesario intercambiar
            }
        }
}


    private void heapifyDown(SuperavitCiudades<T> heap, Tupla ciudad) {
        int indice = posiciones[ciudad.first];
        int tamaño = posiciones.length;
        while (!esHijo(tamaño, indice)) {

            int hijoIzq = 2 * indice + 1;
            int hijoDer = 2 * indice + 2;
            int mayor = hijoIzq; // comenzamos planteando que el mas grande es el izquierdo y luego comparamos si es cierto o no y en base a eso, reemplazamos (hacemos swap)

            // acá comparamos, y en caso de ser necesario, hacemos un swap
            if (hijoDer < tamaño &&
                new superavitComparator().compare(heap.elems[hijoDer], heap.elems[hijoIzq]) > 0) {
                mayor = hijoDer;
            }

            // ahora comparamos el padre con el hijo "mayor" para decidir si es necesario hacer swap
            if (new superavitComparator().compare(heap.elems[indice], heap.elems[mayor]) >= 0) {
                break; // acá no seria necesario hacer ningun cambio
            }

    
            swap(heap, indice, mayor);
        

            // por ultimo, actualizamos el indice y continuamos el proceso
            indice = mayor;
        }
}
private void swap(SuperavitCiudades<T> heap, int posPadre, int posHijo) {
        
    Tupla temp = heap.elems[posPadre];
    heap.elems[posPadre] =  heap.elems[posHijo];
    heap.elems[posHijo] =  temp;
    heap.posiciones[posPadre] = posHijo;
    heap.posiciones[posHijo] = posPadre;
}
private boolean esHijo(int tamaño, int indice) {  // si el índice es mayor que `tamaño/2 - 1`, significa que es un nodo hoja (hijo)
        
    return indice > tamaño / 2 - 1;
}

}
