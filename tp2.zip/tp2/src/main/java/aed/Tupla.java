package aed;

public class Tupla {
        int first;
        int second;

        public Tupla(int first, int second) {
            this.first = first;
            this.second = second;
        }
    }
