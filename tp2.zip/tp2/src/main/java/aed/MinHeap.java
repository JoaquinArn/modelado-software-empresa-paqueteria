package aed;

import java.util.ArrayList;
import java.util.Comparator;

public class MinHeap <T> {
    private ArrayList<TrasladoHandle> elems;
    private int tamaño;


    private class AntiguedadComparator implements Comparator <Traslado> { //O(1)
        @Override
        public int compare(Traslado t1, Traslado t2){
            return Integer.compare(t1.timestamp, t2.timestamp);
        }
    }
  

    //En este caso, al crearnos un MinHeap realizamos unicamente dos asignaciones, lo cual es 0(1)
    public MinHeap() { // constructor del heap vacio
        this.elems = new ArrayList<>();
        this.tamaño = 0; 
    }


    
    // Este proceso tiene un tiempo de ejecución lineal porque, aunque cada operación de heapify tiene
    // un costo logarítmico en el peor caso, el número de nodos en los niveles más profundos del árbol es tan grande
    // que el costo total se distribuye de manera eficiente a lo largo de todos los nodos.
 

    public void array2Heap (Traslado[] traslados){ // algoritmo de floyd para armarnos el heap con la informacion de los traslados. 
       
        this.tamaño = traslados.length;
        this.elems = new ArrayList <>();
        for (int i = 0; i < this.tamaño; i++) {
            this.elems.add(traslados[i]);
    }
        for (int i = this.tamaño / 2 - 1; i >= 0; i--) {

        this.elems = heapifyDown(i);  
    }}

    public void array2HeapAux (ArrayList<Traslado> traslados){ // algoritmo de floyd para armarnos el heap con la informacion de los traslados.
        this.tamaño = traslados.size();
        this.elems = new ArrayList <>();
        for (int i = 0; i < this.tamaño; i++) {
            this.elems.add(traslados.get(i));
        }
        for (int i = this.tamaño / 2 - 1; i >= 0; i--) {
            this.elems = heapifyDown(i);
        }
    }
    // método para agregar un nuevo elemento al heap
    public void encolar(MinHeap <T> heap, Traslado traslado) {         
        heap.elems.add(traslado); //agrega el elemento
        heapifyUp(heap);
        heap.tamaño++;    
    }


    private void heapifyUp(MinHeap <T> heap) {   
        int hijoActual = heap.tamaño - 1;  // comenzamos el proceso en el "ultimo hijo"
        
        boolean necesitaIntercambio = true;  // utilizamos este booleano para poder cortar el while

        while (hijoActual > 0 && necesitaIntercambio) {  // si el hijoActual no es la raiz y todavia no chequeamos si necesita intercambio, entramos al loop
            int padreActual = (hijoActual - 1) / 2;
            if (new AntiguedadComparator().compare(heap.elems.get(hijoActual), heap.elems.get(padreActual)) < 0) { // chequeamos si el "hijoActual" es menr al padre, y si es asi, lo swapeamos 
                swap(heap,padreActual, hijoActual);
                hijoActual = padreActual;
            } 
            else {
                necesitaIntercambio = false;  // detiene el ciclo cuando no es necesario intercambiar
            }
        }
    }


    private ArrayList<Traslado> heapifyDown(int indice) {
        while (!esHijo(this.tamaño, indice)) {

            int hijoIzq = 2 * indice + 1;
            int hijoDer = 2 * indice + 2;
            int menor = hijoIzq; // comenzamos planteando que el mas grande es el izquierdo y luego comparamos si es cierto o no y en base a eso, reemplazamos (hacemos swap)

            // acá comparamos, y en caso de ser necesario, hacemos un swap
            if (hijoDer < this.tamaño){

                if (new AntiguedadComparator().compare(this.elems.get(hijoDer), this.elems.get(hijoIzq)) < 0) {
                    menor = hijoDer;
            }
            }

            // ahora comparamos el padre con el hijo "mayor" para decidir si es necesario hacer swap
            if (new AntiguedadComparator().compare(this.elems.get(indice), this.elems.get(menor)) <= 0) {
                break; // acá no seria necesario hacer ningun cambio
            }

            // intercambio 
            swap(this, indice, menor);
            // por ultimo, actualizamos el indice y continuamos el proceso
            indice = menor;
        }
        return this.elems;
    }


    // método para intercambiar los elementos en las posiciones dadas dentro del heap
    private void swap(MinHeap<T> heap, int posPadre, int posHijo) {
        
        Traslado temp = heap.elems.get(posPadre);
      
        heap.elems.set(posPadre, heap.elems.get(posHijo));
        
        heap.elems.set(posHijo, temp);
    }

    // extrae el elemento máximo del heap
    public Traslado [] desencolarMin(MinHeap<T> heap, int n, MaxHeap<T> redituabilidadTraslados) {
        Traslado[] res = new Traslado[n];
        int i = 0;
        while (i< n){
            Traslado trasladoEliminado = elems.get(0);
            res[i] = trasladoEliminado;
            elems.set(0, elems.get(tamaño - 1)); 
            elems.set(tamaño - 1, null); // establece la última posición como `null` para "eliminar" el último elemento
        
        // inicia el proceso de "heapificación hacia abajo" desde la raíz para restaurar la estructura del heap
        
            int indice = 0;
            heapifyDown(indice);
            i+= 1;
            tamaño--;
        }
        redituabilidadTraslados.array2HeapAux(elems);
      
        return res;
    }

    
    private boolean esHijo(int tamaño, int indice) {  // si el índice es mayor que `tamaño/2 - 1`, significa que es un nodo hoja (hijo)
        
        return indice > tamaño / 2 - 1;
    }

}

