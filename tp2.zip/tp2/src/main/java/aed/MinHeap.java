package aed;

import java.util.ArrayList;
import java.util.Comparator;

public class MinHeap <T> {
    private ArrayList<Traslado> elems;
    private ArbolAVL handles;
    private int tamaño;


    private class AntiguedadComparator implements Comparator <Traslado> {
        @Override
        public int compare(Traslado t1, Traslado t2){
            return Integer.compare(t1.timestamp, t2.timestamp);
        }
    }
  


    public MinHeap() { // constructor del heap vacio
        this.elems = new ArrayList<>();
        this.tamaño = 0;
        this.handles = new ArbolAVL();
}


public void array2Heap (Traslado[] traslados){ // algoritmo de floyd para armarnos el heap con la informacion de los traslados. 
       
    this.tamaño = traslados.length;
    this.elems = new ArrayList <>();
    for (int i = 0; i < this.tamaño; i++) {
        this.elems.add(traslados[i]);
}
    for (int i = this.tamaño / 2 - 1; i >= 0; i--) {

    this.elems = heapifyDown(this, i);  
}
for (int i = 0; i < this.tamaño; i++) {
    Tupla nuevoElemento = new Tupla(traslados[i].id,i);
    this.handles.insertar(handles, nuevoElemento.first, nuevoElemento.second);
}

}
    // método para agregar un nuevo elemento al heap
    public void encolar(MinHeap <T> heap, Traslado traslado) { 
        
        heap.elems.add(traslado); //agrega el elemento

        Tupla nuevoHandle = new Tupla(traslado.id, heap.tamaño); 
        heap.handles.insertar(heap.handles,nuevoHandle.first,nuevoHandle.second); //actualiza en AVL con el nuevo handle
        heapifyUp(heap);
        heap.tamaño++;    
}


    private void heapifyUp(MinHeap <T> heap) {   
        int hijoActual = heap.tamaño - 1;  // comenzamos el proceso en el "ultimo hijo"
        
        boolean necesitaIntercambio = true;  // utilizamos este booleano para poder cortar el while

        while (hijoActual > 0 && necesitaIntercambio) {  // si el hijoActual no es la raiz y todavia no chequeamos si necesita intercambio, entramos al loop

            int padreActual = (hijoActual - 1) / 2;

            if (new AntiguedadComparator().compare(heap.elems.get(hijoActual), heap.elems.get(padreActual)) < 0) { // chequeamos si el "hijoActual" es menr al padre, y si es asi, lo swapeamos 

                swap(heap,padreActual, hijoActual);
                hijoActual = padreActual;
            } else {
                necesitaIntercambio = false;  // detiene el ciclo cuando no es necesario intercambiar
            }
        }
}


    private ArrayList<Traslado> heapifyDown(MinHeap<T> heap, int indice) {

        while (!esHijo(heap.tamaño, indice)) {

            int hijoIzq = 2 * indice + 1;
            int hijoDer = 2 * indice + 2;
            int menor = hijoIzq; // comenzamos planteando que el mas chico es el izquierdo y luego comparamos si es cierto o no y en base a eso, reemplazamos (hacemos swap)

            // acá comparamos, y en caso de ser necesario, hacemos un swap
            if (hijoDer < heap.tamaño &&
                new AntiguedadComparator().compare(heap.elems.get(hijoDer), heap.elems.get(hijoIzq)) < 0) {
                menor = hijoDer;
            }

            // ahora comparamos el padre con el hijo "menor" para decidir si es necesario hacer swap
            if (new AntiguedadComparator().compare(heap.elems.get(indice), heap.elems.get(menor)) <= 0) {
                break; // acá no seria necesario hacer ningun cambio
            }

            // intercambio y actualización en handles (AVL)
            int idPadre = heap.elems.get(indice).timestamp;
            int idMayor = heap.elems.get(menor).timestamp;
            swap(heap, indice, menor);
            
            // actualizamos los handles de posiciones en el heap
            heap.handles.modificarValor(handles,idMayor,indice);
            heap.handles.modificarValor(handles,idPadre,menor);

            // por ultimo, actualizamos el indice y continuamos el proceso
            indice = menor;
        }
        return heap.elems;
}


    // método para intercambiar los elementos en las posiciones dadas dentro del heap
    private void swap(MinHeap<T> heap, int posPadre, int posHijo) {
        
        Traslado temp = heap.elems.get(posPadre);
      
        heap.elems.set(posPadre, heap.elems.get(posHijo));
        
        heap.elems.set(posHijo, temp);
}

    // extrae el elemento máximo del heap
    public int desencolarMin(MinHeap<T> heap) {
        // elimina el handle (en el AVL) del primer elemento en el heap usando su ID
        handles.eliminar(elems.get(0).id);
        
        int idEliminado = elems.get(0).id;
       
        elems.set(0, elems.get(tamaño - 1)); 
        elems.set(tamaño - 1, null); // establece la última posición como `null` para "eliminar" el último elemento
        
        // inicia el proceso de "heapificación hacia abajo" desde la raíz para restaurar la estructura del heap
        
        int indice = 0;
        heapifyDown(heap,indice);
      
        tamaño--;
      
        return idEliminado;
}

    
    private boolean esHijo(int tamaño, int indice) {  // si el índice es mayor que `tamaño/2 - 1`, significa que es un nodo hoja (hijo)
        
        return indice > tamaño / 2 - 1;
}

    // método para eliminar un elemento del heap dado su ID
    public Traslado eliminar(MinHeap<T> heap, int id) {
        
        int indice = heap.handles.buscarPosic(heap.handles,id);// busca la posición del elemento con el ID especificado en el heap
        
        heap.handles.eliminar(id);// lo elimina
        Traslado valorAntiguo = heap.elems.get(indice);
        Traslado valorDeCambio = heap.elems.get(tamaño - 1);
        heap.elems.set(indice, valorDeCambio);
        // "elimina" el último elemento, estableciendo su posición en `null`
        elems.set(heap.tamaño - 1, null);
        if (new AntiguedadComparator().compare(valorAntiguo, valorDeCambio) > 0) { // si el `valorAntiguo` es mayor que el `valorDeCambio`, llama a `heapifyUp`
            heapifyUp(heap);
        } else {  // si no, llama a `heapifyDown` desde el índice actual
           
            heapifyDown(heap, indice);
        }
        heap.tamaño--;
        return valorAntiguo;
}


}

