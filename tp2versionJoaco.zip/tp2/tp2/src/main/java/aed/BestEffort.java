package aed;

import java.util.ArrayList;

public class BestEffort {
    //Completar atributos privados
    private SuperavitCiudades<int[]> superavitCiudades;
    private Heap redituabilidadTraslados;
    private Heap antiguedadTraslados;
    private int[] gananciasCiudades;
    private int[] perdidasCiudades;
    private ArrayList<Integer> ciudadesMasLucrativas;
    private ArrayList<Integer> ciudadesMenosLucrativas;
    private int gananciaMaxima;
    private int perdidaMaxima;
    private Tupla amountAndProfitDespachos;


    //Al inicializar todas las asignaciones son O(1) salvo en superavitCiudades que es O(|C|) y además los llamados arra2Heap para redituabilidadTraslados y antiguedadTraslados tienen complejidad O(|T|).
    // Complejidad final O(|C|+|T|) 
    public BestEffort(int cantCiudades, Traslado[] traslados){
        // Inicialización de los atributos
        this.superavitCiudades = new SuperavitCiudades<int[]>(cantCiudades); //O(|C|)
        this.redituabilidadTraslados = new Heap();
        this.antiguedadTraslados = new Heap();
        this.gananciasCiudades = new int[cantCiudades]; 
        this.perdidasCiudades = new int[cantCiudades];
        this.ciudadesMasLucrativas = new ArrayList<>();
        this.ciudadesMenosLucrativas = new ArrayList<>();
        this.gananciaMaxima = 0;
        this.perdidaMaxima = 0;
        this.amountAndProfitDespachos = new Tupla(0,0);
        Comparador comparadorRedituabilidad = new Comparador("redituabilidad");
        Comparador comparadorAntiguedad = new Comparador("antiguedad");
        Handle [] secuenciHandles = new Handle[traslados.length];
        for (int i = 0; i< traslados.length; i++){
            Handle handleAmarreTraslado = new Handle(traslados[i]); 
            secuenciHandles[i] = handleAmarreTraslado;
        } //O(|T|)
        TrasladoAmarrado [] arrayAHeap = new TrasladoAmarrado [traslados.length];
        for (int j = 0; j< traslados.length; j++){
            TrasladoAmarrado trasladoConSuHandle = new TrasladoAmarrado(traslados[j], secuenciHandles[j]);
            arrayAHeap[j] = trasladoConSuHandle;
        } //O(|T|)

        redituabilidadTraslados.array2Heap(arrayAHeap, comparadorRedituabilidad, "redito"); //O(|T|)
        antiguedadTraslados.array2Heap(arrayAHeap, comparadorAntiguedad, "antiguedad");    //O(|T|)
    }
    
    // La complejidad requerida para este ejercicio es O(|traslados|log(|T|)). En el codigo, se ve de la siguiente forma:
    // Vamos a tener que ingresar al sistema ´n´ traslados, este n viene determinado por el largo de la lista que se nos da para registrar en el sistema.
    // Para cada uno de los traslados que van a ser ingresados al sistema tenemos que recorrer el MaxHeap, lo cual nos lleva Log n (para cada uno).
    // Nos queda entonces, como mencionamos al comienzo, O(|traslados|. log(|T|)).
    public void registrarTraslados(Traslado[] traslados){
        Comparador comparadorRedituabilidad = new Comparador("redituabilidad");
        Comparador comparadorAntiguedad = new Comparador("antiguedad");
        Handle [] secuenciHandles = new Handle[traslados.length];
        for (int i = 0; i< traslados.length; i++){
            Handle handleAmarreTraslado = new Handle(traslados[i]); 
            secuenciHandles[i] = handleAmarreTraslado;
        } //O(|T|)
        TrasladoAmarrado [] trasladosAlHeap = new TrasladoAmarrado [traslados.length];
        for (int j = 0; j< traslados.length; j++){
            TrasladoAmarrado trasladoConSuHandle = new TrasladoAmarrado(traslados[j], secuenciHandles[j]);
            trasladosAlHeap[j] = trasladoConSuHandle;
        } //O(|T|)

        for (int k = 0; k < trasladosAlHeap.length; k++){
            redituabilidadTraslados.encolar(trasladosAlHeap[k], comparadorRedituabilidad, "redito");
            antiguedadTraslados.encolar(trasladosAlHeap[k],comparadorAntiguedad,  "antiguedad");
        }
    
}
// Se requiere que la complejidad este acotada por 0(n.(Log |T|+ Log |C|)). Esto se ve reflejado de la siguiente forma:
// O(n Log |T|) es desencolar ´n´ veces el máximo de mi MaxHeap "redituabilidadTraslados".
// O(n Log |C|) es modificar la ganancia y la perdida ´n´ veces del MaxHeap "superávitCiudades". 
// Por ultimo redefinimos el MinHeap "antiguedadTraslados", que nos lleva por el algoritmo de floyd (hablamos de su complejidad en el archivo "MaxHeap" y "MinHeap") O(n).
public int[] despacharMasRedituables(int n){
    Comparador comparadorRedituabilidad = new Comparador("redituabilidad");
    Comparador comparadorAntiguedad = new Comparador("antiguedad");
    TrasladoAmarrado [] trasladosEliminados = redituabilidadTraslados.desencolar(n, comparadorRedituabilidad, "redito"); // O(n Log |T|)
    int [] res = new int[n];                                                               
    for (int k = 0; k < n; k++){
        Traslado traslado = trasladosEliminados[k].traslado;
        antiguedadTraslados.eliminar(trasladosEliminados[k].handle.posiciones.second, comparadorAntiguedad, "antiguedad");                                                        
        superavitCiudades.modificarHeap(traslado.origen, traslado.destino, traslado.gananciaNeta); //O(n Log |C|)
        gananciasCiudades[traslado.origen] += traslado.gananciaNeta;
        perdidasCiudades[traslado.destino] += traslado.gananciaNeta;
        amountAndProfitDespachos.second += traslado.gananciaNeta;
        res[k] = traslado.id;

        if (gananciasCiudades[traslado.origen] > gananciaMaxima ){
            ciudadesMasLucrativas.clear();
            ciudadesMasLucrativas.add(traslado.origen);
            gananciaMaxima = gananciasCiudades[traslado.origen];
        }
        else if (gananciasCiudades[traslado.origen] == gananciaMaxima){
            ciudadesMasLucrativas.add(traslado.origen);
        }
        if (perdidasCiudades[traslado.destino] > perdidaMaxima ){
            ciudadesMenosLucrativas.clear();
            ciudadesMenosLucrativas.add(traslado.destino);
            perdidaMaxima = perdidasCiudades[traslado.destino];
        }
        else if (perdidasCiudades[traslado.destino] == perdidaMaxima){
            ciudadesMenosLucrativas.add(traslado.destino);
        }
    };
    amountAndProfitDespachos.first += n;
    return res;
    }



    // Al igual que en "despacharMasRedituables" la complejidad debe ser acotada por O(n (Log(|T|) +Log(|C|) ))
    // O(n Log |T|) es desencolar ´n´ veces el máximo de mi MaxHeap "antiguedadTraslados".
    // O(n Log |C|) es modificar la ganancia y la perdida ´n´ veces del MaxHeap "superávitCiudades".
    // Por ultimo redefinimos el MaxHeap "redituabilidadTraslados", que nos lleva por el algoritmo de floyd (hablamos de su complejidad en el archivo "MaxHeap" y "MinHeap") O(n).
    public int[] despacharMasAntiguos(int n){
        Comparador comparadorRedituabilidad = new Comparador("redituabilidad");
        Comparador comparadorAntiguedad = new Comparador("antiguedad");
        TrasladoAmarrado [] trasladosEliminados = antiguedadTraslados.desencolar(n, comparadorAntiguedad, "antiguedad"); // O(n Log |T|)
        int [] res = new int[n];                                                        // Al pasar como dato el MaxHeap "redituabilidadTraslados" nos seguramos de "eliminar" 
        for (int k = 0; k < n; k++){                        
            Traslado traslado = trasladosEliminados[k].traslado;
            redituabilidadTraslados.eliminar(trasladosEliminados[k].handle.posiciones.first, comparadorRedituabilidad, "redito");                                       //los traslados ya despachados en O(| T|-n), usando nuevamente el algoritmo de Floyd 
            superavitCiudades.modificarHeap(traslado.origen, traslado.destino, traslado.gananciaNeta);//O(n Log |C|)
            
            gananciasCiudades[traslado.origen] += traslado.gananciaNeta;
            perdidasCiudades[traslado.destino] += traslado.gananciaNeta;
            amountAndProfitDespachos.second += traslado.gananciaNeta;
            res[k] = traslado.id;
            if (gananciasCiudades[traslado.origen] > gananciaMaxima ){
                ciudadesMasLucrativas.clear();
                ciudadesMasLucrativas.add(traslado.origen);
                gananciaMaxima = gananciasCiudades[traslado.origen];
            }
            else if (gananciasCiudades[traslado.origen] == gananciaMaxima){
                ciudadesMasLucrativas.add(traslado.origen);
            }
            if (perdidasCiudades[traslado.destino] > perdidaMaxima ){
                ciudadesMenosLucrativas.clear();
                ciudadesMenosLucrativas.add(traslado.destino);
                perdidaMaxima = perdidasCiudades[traslado.destino];
            }
            else if (perdidasCiudades[traslado.destino] == perdidaMaxima){
                ciudadesMenosLucrativas.add(traslado.destino);
            }
        };
    amountAndProfitDespachos.first += n;
    return res;
    }

    public int ciudadConMayorSuperavit(){
        return  superavitCiudades.consultarMax(superavitCiudades);
    }


    // Es en O(1) ya que returnea el primer elemento de una lista
    public ArrayList<Integer> ciudadesConMayorGanancia(){
        return ciudadesMasLucrativas;
    }

    public ArrayList<Integer> ciudadesConMayorPerdida(){
        return ciudadesMenosLucrativas;
    }

    public int gananciaPromedioPorTraslado(){
        return amountAndProfitDespachos.second/amountAndProfitDespachos.first;
    }
    
}
