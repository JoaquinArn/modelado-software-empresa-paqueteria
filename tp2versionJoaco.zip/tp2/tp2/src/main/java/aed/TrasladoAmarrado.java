package aed;

public class TrasladoAmarrado {
    Traslado traslado;
    Handle handle;

    public TrasladoAmarrado(Traslado traslado, Handle handle){
        this.traslado = traslado;
        this.handle = handle;
    }
}
