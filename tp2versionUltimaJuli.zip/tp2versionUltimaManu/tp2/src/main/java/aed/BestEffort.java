package aed;

import java.util.ArrayList;

public class BestEffort {
    //Completar atributos privados
    private SuperavitCiudades<int[]> superavitCiudades;
    private Heap redituabilidadTraslados;
    private Heap antiguedadTraslados;
    private int[] gananciasCiudades;
    private int[] perdidasCiudades;
    private ArrayList<Integer> ciudadesMasLucrativas;
    private ArrayList<Integer> ciudadesMenosLucrativas;
    private int gananciaMaxima;
    private int perdidaMaxima;
    private Tupla amountAndProfitDespachos;


    // Al inicializar "BestEffort" se realizan una serie de asignaciones, que son O(1), se inicializa el heap "superavitCiudades" acotado por O(|C|); 
    // Y además la creacion de los heaps "redituabilidadTraslados" y "antiguedadTraslados" que tienen ambos complejidad O(|T|).
    // Complejidad final O(|C|+|T|) 
    public BestEffort(int cantCiudades, Traslado[] traslados){
        // Inicialización de los atributos
        this.superavitCiudades = new SuperavitCiudades<int[]>(cantCiudades); //O(|C|)
        this.redituabilidadTraslados = new Heap();
        this.antiguedadTraslados = new Heap();
        this.gananciasCiudades = new int[cantCiudades]; 
        this.perdidasCiudades = new int[cantCiudades];
        this.ciudadesMasLucrativas = new ArrayList<>();
        this.ciudadesMenosLucrativas = new ArrayList<>();
        this.gananciaMaxima = 0;
        this.perdidaMaxima = 0;
        this.amountAndProfitDespachos = new Tupla(0,0);
        // Inicialización de los comparadores
        Comparador comparadorRedituabilidad = new Comparador("redituabilidad");
        Comparador comparadorAntiguedad = new Comparador("antiguedad");
        // Inicialización de los Handles
        Handle [] secuenciHandles = new Handle[traslados.length];
        for (int i = 0; i< traslados.length; i++){
            Handle handleAmarreTraslado = new Handle(traslados[i]); 
            secuenciHandles[i] = handleAmarreTraslado;
        } //O(|T|)
        // Traslado amarrado llamamos al tipo de dato que utilizaremos en nuestros heaps. Lo creamos para poder tener la facilidad que brindan los Handles a la hora de manipular los heaps.
        TrasladoAmarrado [] arrayAHeap = new TrasladoAmarrado [traslados.length];
        for (int j = 0; j< traslados.length; j++){
            TrasladoAmarrado trasladoConSuHandle = new TrasladoAmarrado(traslados[j], secuenciHandles[j]);
            arrayAHeap[j] = trasladoConSuHandle;
        } //O(|T|)

        // Nos armamos los heaps, a partir de los traslados con sus respectivos Handles.
        redituabilidadTraslados.array2Heap(arrayAHeap, comparadorRedituabilidad, "redito"); //O(|T|)
        antiguedadTraslados.array2Heap(arrayAHeap, comparadorAntiguedad, "antiguedad");    //O(|T|)
    }
    
    // La complejidad requerida para este ejercicio es O(|traslados|log(|T|)). En el codigo, se ve de la siguiente forma:
    // Vamos a tener que ingresar al sistema ´n´ traslados, este n viene determinado por el largo de la lista que se nos da para registrar en el sistema.
    // Para cada uno de los traslados que van a ser ingresados al sistema tenemos que recorrer el MaxHeap, lo cual nos lleva Log n (para cada uno).
    // Nos queda entonces, como mencionamos al comienzo, O(|traslados| log(|T|)).

    public void registrarTraslados(Traslado[] traslados) {
        // Creamos dos comparadores para ordenar los traslados según los criterios de redituabilidad y antigüedad, que vamos a usar para encolarlos.
        Comparador comparadorRedituabilidad = new Comparador("redituabilidad");
        Comparador comparadorAntiguedad = new Comparador("antiguedad");
    
        // Creamos un array de Handles para despues asociar cada traslado con un identificador único.
        Handle[] secuenciHandles = new Handle[traslados.length];
    
        
        for (int i = 0; i < traslados.length; i++) {
            // Creamos un Handle específico para el traslado actual.
            Handle handleAmarreTraslado = new Handle(traslados[i]);
            // Guardamos este Handle en el array secuenciHandles para acceso posterior.
            secuenciHandles[i] = handleAmarreTraslado;
        } // Complejidad: O(|T|), donde |T| es la cantidad de traslados.
    
        // Ahora creamos un array para almacenar TrasladoAmarrado,         
        TrasladoAmarrado[] trasladosAlHeap = new TrasladoAmarrado[traslados.length];
    
        // Para cada traslado, lo "amarramos" con su Handle correspondiente.
        for (int j = 0; j < traslados.length; j++) {
        
            TrasladoAmarrado trasladoConSuHandle = new TrasladoAmarrado(traslados[j], secuenciHandles[j]);
            // Guardamos la instancia en el array para encolarla luego.
            trasladosAlHeap[j] = trasladoConSuHandle;
        } // Complejidad: O(|T|).
    
        // Encolamos cada TrasladoAmarrado en dos heaps: uno por redituabilidad y otro por antigüedad.
        for (int k = 0; k < trasladosAlHeap.length; k++) {          
            redituabilidadTraslados.encolar(trasladosAlHeap[k], comparadorRedituabilidad, "redito");
            antiguedadTraslados.encolar(trasladosAlHeap[k], comparadorAntiguedad, "antiguedad");
        } // Complejidad: O(|T|).
    
    }
    
// Se requiere que la complejidad este acotada por 0(n.(Log |T|+ Log |C|)). Esto se ve reflejado de la siguiente forma:
// O(n Log |T|) es desencolar ´n´ veces el máximo de mi MaxHeap "redituabilidadTraslados".
// O(n Log |C|) es modificar la ganancia y la perdida ´n´ veces del MaxHeap "superávitCiudades". 
// Cada traslado que se elimina de redituabilidadTraslados también se elimina de antiguedadTraslados utilizando la posición almacenada en su handle.
// En un heap, eliminar un elemento dado su posición tiene una complejidad de O(Log(|T|)) (ajustando el heap después de la eliminación).
// Como esto se repite n veces, la complejidad para esta operación es O(n Log(|T|))
// Finalmente tenemos que es O(n log(|T|) + n log(|C|)) o sacando FC O(n (Log(|T|) + Log(|C|)))
public int[] despacharMasRedituables(int n) {

    // Si n es mayor que la cantidad de ciudades con ganancias, ajustamos el valor de n.
    if (n > gananciasCiudades.length) {
        return despacharMasRedituables(gananciasCiudades.length);
    } else {
        // Creamos los comparadores para ordenar según redituabilidad y antigüedad.
        Comparador comparadorRedituabilidad = new Comparador("redituabilidad");
        Comparador comparadorAntiguedad = new Comparador("antiguedad");

        // Sacamos los n traslados más redituables.
        TrasladoAmarrado[] trasladosEliminados = redituabilidadTraslados.desencolar(n, comparadorRedituabilidad, "redito");
        int[] res = new int[n];

        for (int k = 0; k < n; k++) {
            Traslado traslado = trasladosEliminados[k].traslado;
            
            // Eliminamos el traslado del heap de antigüedad usando su handle.
            antiguedadTraslados.eliminar(trasladosEliminados[k].handle.posiciones.second, comparadorAntiguedad, "antiguedad");

            // Actualizamos los datos de superávit para la ciudad de origen y de pérdidas para la de destino.
            superavitCiudades.modificarHeap(traslado.origen, traslado.destino, traslado.gananciaNeta);
            gananciasCiudades[traslado.origen] += traslado.gananciaNeta;
            perdidasCiudades[traslado.destino] += traslado.gananciaNeta;
            amountAndProfitDespachos.second += traslado.gananciaNeta;

            // Guardamos el ID del traslado eliminado.
            res[k] = traslado.id;

            // Actualizamos listas de ciudades más lucrativas y menos lucrativas si es necesario.
            if (gananciasCiudades[traslado.origen] > gananciaMaxima) {
                ciudadesMasLucrativas.clear();
                ciudadesMasLucrativas.add(traslado.origen);
                gananciaMaxima = gananciasCiudades[traslado.origen];
            } 
            else if (gananciasCiudades[traslado.origen] == gananciaMaxima && !ciudadesMasLucrativas.contains(traslado.origen)) {
                ciudadesMasLucrativas.add(traslado.origen);
            }

            if (perdidasCiudades[traslado.destino] > perdidaMaxima) {
                ciudadesMenosLucrativas.clear();
                ciudadesMenosLucrativas.add(traslado.destino);
                perdidaMaxima = perdidasCiudades[traslado.destino];
            } 
            else if (perdidasCiudades[traslado.destino] == perdidaMaxima && !ciudadesMenosLucrativas.contains(traslado.destino)) {
                ciudadesMenosLucrativas.add(traslado.destino);
            }
        }

        // Actualizamos la cantidad total de despachos realizados.
        amountAndProfitDespachos.first += n;
        return res;
    }
}


    // Al igual que en "despacharMasRedituables" la complejidad debe ser acotada por O(n (Log(|T|) +Log(|C|) ))
    // Se requiere que la complejidad este acotada por 0(n.(Log |T|+ Log |C|)). Esto se ve reflejado de la siguiente forma:
    // O(n Log |T|) es desencolar ´n´ veces el máximo de mi MinHeap "antiguedadTraslados".
    // O(n Log |C|) es modificar la ganancia y la perdida ´n´ veces del MaxHeap "superávitCiudades". 
    // Cada traslado que se elimina de antiguedadTraslados también se elimina de redituabilidadTraslados utilizando la posición almacenada en su handle.
    // En un heap, eliminar un elemento dado su posición tiene una complejidad de O(Log(|T|)) (ajustando el heap después de la eliminación).
    // Como esto se repite n veces, la complejidad para esta operación es O(n Log(|T|))
    // Finalmente tenemos que es O(n log(|T|) + n log(|C|)) o sacando FC O(n (Log(|T|) + Log(|C|)))

    public int[] despacharMasAntiguos(int n) {
        // Si n supera la cantidad de ciudades con ganancias, ajustamos el valor de n.
        if (n > gananciasCiudades.length) {
            return despacharMasAntiguos(gananciasCiudades.length);
        } else {
            // Creamos comparadores para ordenar por redituabilidad y antigüedad.
            Comparador comparadorRedituabilidad = new Comparador("redituabilidad");
            Comparador comparadorAntiguedad = new Comparador("antiguedad");
    
            // Sacamos los n traslados más antiguos de la cola de antigüedad.
            TrasladoAmarrado[] trasladosEliminados = antiguedadTraslados.desencolar(n, comparadorAntiguedad, "antiguedad");
            int[] res = new int[n];
    
            // Procesamos cada traslado eliminado.
            for (int k = 0; k < n; k++) {
                Traslado traslado = trasladosEliminados[k].traslado;
    
                // Eliminamos el traslado también del heap de redituabilidad.
                redituabilidadTraslados.eliminar(trasladosEliminados[k].handle.posiciones.first, comparadorRedituabilidad, "redito");
    
                // Actualizamos el superávit y pérdidas para las ciudades de origen y destino del traslado.
                superavitCiudades.modificarHeap(traslado.origen, traslado.destino, traslado.gananciaNeta);
                gananciasCiudades[traslado.origen] += traslado.gananciaNeta;
                perdidasCiudades[traslado.destino] += traslado.gananciaNeta;
                amountAndProfitDespachos.second += traslado.gananciaNeta;
    
                // Guardamos el ID del traslado eliminado.
                res[k] = traslado.id;
    
                // Verificamos si debemos actualizar la lista de ciudades más y menos lucrativas.
                if (gananciasCiudades[traslado.origen] > gananciaMaxima) {
                    ciudadesMasLucrativas.clear();
                    ciudadesMasLucrativas.add(traslado.origen);
                    gananciaMaxima = gananciasCiudades[traslado.origen];
                } 
                else if (gananciasCiudades[traslado.origen] == gananciaMaxima && !ciudadesMasLucrativas.contains(traslado.origen)) {
                    ciudadesMasLucrativas.add(traslado.origen);
                }
    
                if (perdidasCiudades[traslado.destino] > perdidaMaxima) {
                    ciudadesMenosLucrativas.clear();
                    ciudadesMenosLucrativas.add(traslado.destino);
                    perdidaMaxima = perdidasCiudades[traslado.destino];
                } 
                else if (perdidasCiudades[traslado.destino] == perdidaMaxima && !ciudadesMenosLucrativas.contains(traslado.destino)) {
                    ciudadesMenosLucrativas.add(traslado.destino);
                }
            }
    
            // Actualizamos el contador de despachos.
            amountAndProfitDespachos.first += n;
            return res;
        }
    }

    
    // Es en O(1) ya que "consultarMax" es el primer valor del heap superavitCiudades.
    public int ciudadConMayorSuperavit(){
        return  superavitCiudades.consultarMax(superavitCiudades);
    }


    // Es en O(1) ya que devuelve el primer elemento de una lista.

    public ArrayList<Integer> ciudadesConMayorGanancia(){
        return ciudadesMasLucrativas;
    }
    // Es en O(1) ya que devuelve el primer elemento de una lista.

    public ArrayList<Integer> ciudadesConMayorPerdida(){
        return ciudadesMenosLucrativas;
    }
    // Es en O(1) ya que únicamente realiza una operación.
    public int gananciaPromedioPorTraslado(){
        return amountAndProfitDespachos.second/amountAndProfitDespachos.first;
    }
    
}
