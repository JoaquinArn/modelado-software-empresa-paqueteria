package aed;
import java.util.Comparator;


public class ComparadorAntiguedad implements Comparator<Traslado>{
    @Override
    public int compare(Traslado traslado1, Traslado traslado2){
        int timestamp1 = traslado1.timestamp; 
        int timestamp2 = traslado2.timestamp;
        return Integer.compare(timestamp2, timestamp1);
    }
}

