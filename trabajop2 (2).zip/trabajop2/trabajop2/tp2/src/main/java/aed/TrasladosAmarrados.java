package aed;

import java.util.ArrayList;

public class TrasladosAmarrados {
    ArrayList<TrasladoAmarrado> amarres;

    public class TrasladoAmarrado{
        Traslado traslado;
        Handle handle;

        public TrasladoAmarrado(Traslado traslado, Handle handle){ //O(1) la inicialización, pues son simples asignaciones.
            this.traslado = traslado;
            this.handle = handle;
        }
    }

    public TrasladosAmarrados(Traslado [] traslados){
        ArrayList<TrasladoAmarrado> amarres = new ArrayList<TrasladoAmarrado>(traslados.length); //O(1) pues es una inicialización.
        int i = 0; //O(1) pues es una simple asignación
        while (i < traslados.length && traslados[i] != null){
            Handle handle = new Handle(traslados[i]);
            TrasladoAmarrado amarre = new TrasladoAmarrado(traslados[i], handle);
            amarres.add(amarre);
            i = i + 1;
        } //O(|T|) pues hace |T| iteraciones en las que realiza operaciones que son O(1) cada una
        this.amarres = amarres; 
    }//Así, complejidad total: O(|T|)

}
