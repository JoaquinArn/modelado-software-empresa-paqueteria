package aed;


public class Handle {
    Tupla posiciones; 

    // Constructor que del Handle.
    public Handle(Traslado traslado) {
        posiciones = new Tupla(-1, -1); // Decidimos inicializar en -1 porque no es un "indice" válido.
    }

    // Modifica la posición de un traslado según la palabra clave.
    public void modificarPosicion(Traslado traslado, int indice, String palabraClave) {
        if (palabraClave.equals("redito")) { // Si es 'redito', se actualiza el primer campo.
            this.posiciones.first = indice;
        } else if (palabraClave.equals("antiguedad")) { // Si es 'antiguedad', se actualiza el segundo campo.
            this.posiciones.second = indice;
        }
    }

    // Devuelve la posición del traslado indicada por la palabra clave.
    public int consultarPosicion(Traslado traslado, String palabraClave) {
        if (palabraClave.equals("redito")) { // Si es 'redito', devuelve el primer campo.
            return this.posiciones.first;
        } else if (palabraClave.equals("antiguedad")) { // Si es 'antiguedad', devuelve el segundo campo.
            return posiciones.second;
        }
        return -1; // En caso de palabra clave no válida, devuelve -1.
    }
}