package aed;

import java.util.ArrayList;

public class EstadisticasCiudades {
    int[] ganancias;
    int[] perdidas;
    ArrayList<Integer> masLucrativas;
    ArrayList<Integer> menosLucrativas;
    int gananciaMaxima;
    int perdidaMaxima;
    Tupla amountAndProfitDespachos;
    
    public EstadisticasCiudades(int cantCiudades){ //Presenta una complejidad O(|C|) pues:
        this.ganancias = new int[cantCiudades]; //O(1)
        this.perdidas = new int[cantCiudades]; //O(1)
        this.masLucrativas = new ArrayList<>();//O(1)
        this.menosLucrativas = new ArrayList<>();//O(1)
        this.gananciaMaxima = 0; //O(1)
        this.perdidaMaxima = 0; //O(1)
        this.amountAndProfitDespachos =new Tupla(0,0); // O(1)
        for (int i = 0;i < ganancias.length; i++){ //|C| iteraciones
            masLucrativas.add(i); //O(1)
            menosLucrativas.add(i); //O(1)
        } //el for presenta una complejidad O(|C|)
    } //Así, la complejidad total queda: 7O(1) + O(|C|) = O(|C|)


    public void actualizar(Traslado traslado){ //Presenta una complejidad O(1) pues:
        ganancias[traslado.origen] += traslado.gananciaNeta; //O(1)
        perdidas[traslado.destino] += traslado.gananciaNeta; //O(1)
        amountAndProfitDespachos.first += 1; //O(1)
        amountAndProfitDespachos.second += traslado.gananciaNeta; //O(1)
        if (ganancias[traslado.origen] > gananciaMaxima) { //O(1)
            masLucrativas.clear();
            masLucrativas.add(traslado.origen);
            gananciaMaxima= ganancias[traslado.origen];
        } 
        else if (ganancias[traslado.origen] == gananciaMaxima) { //O(1)
            masLucrativas.add(traslado.origen);
        }

        if (perdidas[traslado.destino] > perdidaMaxima) { //O(1)
            menosLucrativas.clear();
            menosLucrativas.add(traslado.destino);
            perdidaMaxima = perdidas[traslado.destino];
        } 
        else if (perdidas[traslado.destino] == perdidaMaxima) { //O(1)
            menosLucrativas.add(traslado.destino);
        }
    } //Así, complejidad = O(1)


    public int consultarPromedio(){ //Presenta una complejidad O(1) pues:
        if (this.amountAndProfitDespachos.first == 0){ //O(1)
            return 0;
        }
        else{ //O(1)
            return (this.amountAndProfitDespachos.second) / (this.amountAndProfitDespachos.first);
        }
    } //Así: complejidad = O(1)

}
