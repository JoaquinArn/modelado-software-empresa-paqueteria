package aed;

public class Handle{
    Tupla posiciones;

    public Handle(Traslado traslado){
        posiciones = new Tupla(-1, -1);
    }

    public void modificarPosicion(Traslado traslado, int indice, String palabraClave){
        if (palabraClave == "redito"){
            this.posiciones.first = indice;
        }
        else if (palabraClave == "antiguedad"){
            this.posiciones.second = indice;
        }
    }

    public int consultarPosicion (Traslado traslado, String palabraClave){
        if (palabraClave == "redito"){
            return this.posiciones.first;
        }
        else if (palabraClave == "antiguedad"){
            return posiciones.second;
        }
        return -1; 
    }

}