package aed;

public class Tupla {
        int first;
        int second;

        public Tupla(int first, int second) { //O(1) simples asignaciones 
            this.first = first;
            this.second = second;
        }
    }
