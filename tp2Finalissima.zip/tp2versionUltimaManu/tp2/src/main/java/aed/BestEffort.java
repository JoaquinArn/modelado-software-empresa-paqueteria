package aed;

import java.util.ArrayList;

public class BestEffort {
    //Completar atributos privados
    private SuperavitCiudades<int[]> superavitCiudades;
    private Heap redituabilidadTraslados;
    private Heap antiguedadTraslados;
    private EstadisticasCiudades estadisticas;


    //EJERCICIO 1
    // Al inicializar "BestEffort" se realizan una serie de asignaciones, que son O(1), se inicializa el heap "superavitCiudades" acotado por O(|C|); 
    // Y además la creacion de los heaps "redituabilidadTraslados" y "antiguedadTraslados" que tienen ambos complejidad O(|T|).
    // Complejidad final O(|C|+|T|) 
    public BestEffort(int cantCiudades, Traslado[] traslados){
        // Inicialización de los atributos
        this.superavitCiudades = new SuperavitCiudades<int[]>(cantCiudades); //O(|C|)
        this.redituabilidadTraslados = new Heap();
        this.antiguedadTraslados = new Heap();
        int [] ganancias = new int[cantCiudades]; 
        int [] perdidas = new int[cantCiudades];
        ArrayList<Integer> masLucrativas = new ArrayList<>();
        ArrayList<Integer> menosLucrativas = new ArrayList<>();
        int gananciaMaxima= 0;
        int perdidaMaxima = 0;
        Tupla amountAndProfitDespachos = new Tupla(0,0);
        this.estadisticas = new EstadisticasCiudades(ganancias, perdidas, masLucrativas, menosLucrativas ,gananciaMaxima, perdidaMaxima, amountAndProfitDespachos);
        // Inicialización de los comparadores
        Comparador comparadorRedituabilidad = new Comparador("redituabilidad");
        Comparador comparadorAntiguedad = new Comparador("antiguedad");
        // Inicialización de los Handles
        Handle [] secuenciHandles = new Handle[traslados.length];
        for (int i = 0; i< traslados.length; i++){
            Handle handleAmarreTraslado = new Handle(traslados[i]); 
            secuenciHandles[i] = handleAmarreTraslado;
        } //O(|T|), pues |T| es la cantidad de iteraciones que realizo, y en cada iteración realizo operaciones elementales
        // Traslado amarrado llamamos al tipo de dato que utilizaremos en nuestros heaps. Lo creamos para poder tener la facilidad que brindan los Handles a la hora de manipular los heaps.
        TrasladoAmarrado [] arrayAHeap = new TrasladoAmarrado [traslados.length];
        for (int j = 0; j< traslados.length; j++){
            TrasladoAmarrado trasladoConSuHandle = new TrasladoAmarrado(traslados[j], secuenciHandles[j]);
            arrayAHeap[j] = trasladoConSuHandle;
        } //O(|T|), mismo criterio que el anterior
        // Nos armamos los heaps, a partir de los traslados con sus respectivos Handles.
        redituabilidadTraslados.array2Heap(arrayAHeap, comparadorRedituabilidad, "redito"); //O(|T|)
        antiguedadTraslados.array2Heap(arrayAHeap, comparadorAntiguedad, "antiguedad");    //O(|T|)
    } //Así: O(|C|) + O(|T|) + O(|T|) + O(|T|) + O(|T|) = O(|T|+|C|)
    


    //EJERCICIO 2
    // La complejidad requerida para este ejercicio es O(|traslados|log(|T|)). En el codigo, se ve de la siguiente forma:
    // Vamos a tener que ingresar al sistema ´n´ traslados, este n viene determinado por el largo de la lista que se nos da para registrar en el sistema.
    // Para cada uno de los traslados que van a ser ingresados, encolarlos en los Heaps de traslados nos lleva  O(log n) (para cada uno).
    // Nos queda entonces, como mencionamos al comienzo, O(|traslados| log(|T|)).
    public void registrarTraslados(Traslado[] traslados) {
        // Creamos dos comparadores para ordenar los traslados según los criterios de redituabilidad y antigüedad, que vamos a usar para encolarlos.
        Comparador comparadorRedituabilidad = new Comparador("redituabilidad");
        Comparador comparadorAntiguedad = new Comparador("antiguedad");
    
        // Creamos un array de Handles para despues asociar cada traslado con un identificador único.
        Handle[] secuenciHandles = new Handle[traslados.length];    
        for (int i = 0; i < traslados.length; i++) {
            // Creamos un Handle específico para el traslado actual.
            Handle handleAmarreTraslado = new Handle(traslados[i]);
            // Guardamos este Handle en el array secuenciHandles para acceso posterior.
            secuenciHandles[i] = handleAmarreTraslado;
        } // Complejidad: O(|traslados|), donde |traslados| es la cantidad de traslados nuevos.
    
        // Ahora creamos un array para almacenar TrasladoAmarrado,         
        TrasladoAmarrado[] trasladosAlHeap = new TrasladoAmarrado[traslados.length];
    
        // Para cada traslado, lo "amarramos" con su Handle correspondiente.
        for (int j = 0; j < traslados.length; j++) {
            TrasladoAmarrado trasladoConSuHandle = new TrasladoAmarrado(traslados[j], secuenciHandles[j]);
            // Guardamos la instancia en el array para encolarla luego.
            trasladosAlHeap[j] = trasladoConSuHandle;
        } // Complejidad: O(|traslados|).
    
        // Encolamos cada TrasladoAmarrado en dos heaps: uno por redituabilidad y otro por antigüedad.
        for (int k = 0; k < trasladosAlHeap.length; k++) {       //|traslados| iteraciones   
            redituabilidadTraslados.encolar(trasladosAlHeap[k], comparadorRedituabilidad, "redito"); //O(log|T|)
            antiguedadTraslados.encolar(trasladosAlHeap[k], comparadorAntiguedad, "antiguedad");//O(log|T|)
        } // Complejidad: O(|traslados|log |T|).
    
    } //Complejidad : O(|traslados|log|T|) + O(|traslados|) = O(|traslados|log|T|)
    


    //EJERCICIO 3
    // Se requiere que la complejidad este acotada por 0(n.(log |T|+ log |C|)). Esto se ve reflejado de la siguiente forma:
    // O(n log |T|) es desencolar ´n´ veces el máximo de mi Heap "redituabilidadTraslados".
    // O(n log |C|) es modificar la ganancia y la perdida ´n´ veces del heap "SuperávitCiudades". 
    // Cada traslado que se desencola de redituabilidadTraslados también se elimina de antiguedadTraslados utilizando la posición almacenada en su handle. Como nuestro handle almacena la posicion en antiguedadTraslados en la que se encuentra el traslado desencolado, buscarlo lleva O(1), y su eliminación toma O(n log|T|)
    // Como esto se repite n veces, la complejidad para esta operación es O(n log(|T|))
    // Finalmente tenemos que es O(n log(|T|) + n log(|C|)) o sacando Factor Común O(n (log(|T|) + log(|C|)))
    public int[] despacharMasRedituables(int n) {
        // Creamos los comparadores para ordenar según redituabilidad y antigüedad.
        Comparador comparadorRedituabilidad = new Comparador("redituabilidad");
        Comparador comparadorAntiguedad = new Comparador("antiguedad");

        // Desencolamos los n traslados más redituables.
        TrasladoAmarrado[] trasladosEliminados = redituabilidadTraslados.desencolar(n, comparadorRedituabilidad, "redito"); //O(n log |T|)
        int[] res = new int[trasladosEliminados.length];
        for (int k = 0; k < trasladosEliminados.length; k++) {//|n| iteraciones
            
            Traslado traslado = trasladosEliminados[k].traslado;
            
            // Eliminamos el traslado del heap de antigüedad usando su handle.
            antiguedadTraslados.eliminar(trasladosEliminados[k].handle.posiciones.second, comparadorAntiguedad, "antiguedad"); //O(log |T|)

            // Actualizamos los datos de superávit para la ciudad de origen y de pérdidas para la de destino; y lo que se halla en EstadisticasCiudades.
            superavitCiudades.modificarHeap(traslado.origen, traslado.destino, traslado.gananciaNeta); //O(log|C|)
            estadisticas.ganancias[traslado.origen] += traslado.gananciaNeta;
            estadisticas.perdidas[traslado.destino] += traslado.gananciaNeta;
            estadisticas.amountAndProfitDespachos.second += traslado.gananciaNeta;

            // Guardamos el ID del traslado eliminado.
            res[k] = traslado.id;

            // Actualizamos listas de ciudades más lucrativas y menos lucrativas si es necesario.
            if (estadisticas.ganancias[traslado.origen] > estadisticas.gananciaMaxima) {
                estadisticas.masLucrativas.clear();
                estadisticas.masLucrativas.add(traslado.origen);
                estadisticas.gananciaMaxima= estadisticas.ganancias[traslado.origen];
            } 
            else if (estadisticas.ganancias[traslado.origen] == estadisticas.gananciaMaxima) {
                estadisticas.masLucrativas.add(traslado.origen);
            }

            if (estadisticas.perdidas[traslado.destino] > estadisticas.perdidaMaxima) {
                estadisticas.menosLucrativas.clear();
                estadisticas.menosLucrativas.add(traslado.destino);
                estadisticas.perdidaMaxima = estadisticas.perdidas[traslado.destino];
            } 
            else if (estadisticas.perdidas[traslado.destino] == estadisticas.perdidaMaxima) {
                estadisticas.menosLucrativas.add(traslado.destino);
            }
        } //Complejidad: O(n (log |C| + log |T|)). Nota: todo el resto de operaciones cuestan O(1)

        // Actualizamos la cantidad total de despachos realizados.
        estadisticas.amountAndProfitDespachos.first += n;
        return res;

    }//Complejidad: O(n (log |C| + log |T|)) + O(n log|T|) = O(n (log |C| + log |T|))



    //EJERCICIO 4
    // Al igual que en "despacharMasRedituables" la complejidad debe ser acotada por O(n (log(|T|) + log(|C|) ))
    // Se requiere que la complejidad este acotada por 0(n.(log |T|+ log |C|)). Esto se ve reflejado de la siguiente forma:
    // O(n log |T|) es desencolar ´n´ veces el máximo de mi Heap "antiguedadTraslados".
    // O(n log |C|) es modificar la ganancia y la perdida ´n´ veces del heap "SuperávitCiudades". 
    // Cada traslado que se elimina de antiguedadTraslados también se elimina de redituabilidadTraslados utilizando la posición almacenada en su handle.
    // En un Heap, eliminar un elemento dado su posición tiene una complejidad de O(log(|T|)) (ajustando el Heap después de la eliminación).
    // Como esto se repite n veces, la complejidad para esta operación es O(n log(|T|))
    // Finalmente tenemos que es O(n log(|T|) + n log(|C|)) o sacando Factor Comun O(n (log(|T|) + log(|C|)))

    public int[] despacharMasAntiguos(int n) {
            // Creamos comparadores para ordenar por redituabilidad y antigüedad.
            Comparador comparadorRedituabilidad = new Comparador("redituabilidad");
            Comparador comparadorAntiguedad = new Comparador("antiguedad");
    
            // Desencolamos los n traslados más antiguos de la cola de antigüedad.
            TrasladoAmarrado[] trasladosEliminados = antiguedadTraslados.desencolar(n, comparadorAntiguedad, "antiguedad");
            int[] res = new int[trasladosEliminados.length];
    
            // Procesamos cada traslado eliminado.
            for (int k = 0; k < trasladosEliminados.length; k++) {
                Traslado traslado = trasladosEliminados[k].traslado;
    
                // Eliminamos el traslado también del Heap de redituabilidad.
                redituabilidadTraslados.eliminar(trasladosEliminados[k].handle.posiciones.first, comparadorRedituabilidad, "redito");
    
                // Actualizamos el superávit y pérdidas para las ciudades de origen y destino del traslado. Modificamos lo que se halla en EstadisticasCiudades
                superavitCiudades.modificarHeap(traslado.origen, traslado.destino, traslado.gananciaNeta);
                estadisticas.ganancias[traslado.origen] += traslado.gananciaNeta;
                estadisticas.perdidas[traslado.destino] += traslado.gananciaNeta;
                estadisticas.amountAndProfitDespachos.second += traslado.gananciaNeta;
    
                // Guardamos el ID del traslado eliminado.
                res[k] = traslado.id;
    
                // Verificamos si debemos actualizar la lista de ciudades más y menos lucrativas.
                if (estadisticas.ganancias[traslado.origen] > estadisticas.gananciaMaxima) {
                    estadisticas.masLucrativas.clear();
                    estadisticas.masLucrativas.add(traslado.origen);
                    estadisticas.gananciaMaxima = estadisticas.ganancias[traslado.origen];
                } 
                else if (estadisticas.ganancias[traslado.origen] == estadisticas.gananciaMaxima) {
                    estadisticas.masLucrativas.add(traslado.origen);
                }
    
                if (estadisticas.perdidas[traslado.destino] > estadisticas.perdidaMaxima) {
                    estadisticas.menosLucrativas.clear();
                    estadisticas.menosLucrativas.add(traslado.destino);
                    estadisticas.perdidaMaxima = estadisticas.perdidas[traslado.destino];
                } 
                else if (estadisticas.perdidas[traslado.destino] == estadisticas.perdidaMaxima) {
                    estadisticas.menosLucrativas.add(traslado.destino);
                }
            }//Complejidad: O(n (log |C| + log |T|)). Nota: todo el resto de operaciones cuestan O(1)
    
            // Actualizamos el contador de despachos.
            estadisticas.amountAndProfitDespachos.first += n;
            return res;
        
    }//Complejidad: O(n (log |C| + log |T|)) + O(n log|T|) = O(n (log |C| + log |T|))

    


    //EJERCICIO 5
    // Es en O(1) ya que "consultarMax" es el primer valor del heap SuperavitCiudades.
    public int ciudadConMayorSuperavit(){
        return  superavitCiudades.consultarMax(superavitCiudades);
    }



    //EJERCICIO 6
    // Es en O(1) ya que devuelve el primer elemento de una lista.
    public ArrayList<Integer> ciudadesConMayorGanancia(){
        return estadisticas.masLucrativas;
    }


    //EJERCICIO 7
    // Es en O(1) ya que devuelve el primer elemento de una lista.
    public ArrayList<Integer> ciudadesConMayorPerdida(){
        return estadisticas.menosLucrativas;
    }



    //EJERCICIO 8
    // Es en O(1) ya que únicamente realiza una operación.
    public int gananciaPromedioPorTraslado(){
        return estadisticas.amountAndProfitDespachos.second/estadisticas.amountAndProfitDespachos.first;
    }
    
}
