package aed;

import java.util.Comparator;

// Comparador adaptable.
public class Comparador implements Comparator<Traslado> {
        private String criterio;


        public Comparador(String pauta){
            criterio = pauta;
            }
        @Override

        public int compare(Traslado traslado1, Traslado traslado2) {
            if (criterio == "redituabilidad"){
                int ganancia1 = traslado1.gananciaNeta; 
                int ganancia2 = traslado2.gananciaNeta;
    
                if (ganancia1 == ganancia2) { 
                    int id1 = traslado1.id;
                    int id2 = traslado2.id;        
                    return Integer.compare(id2, id1);
                } // Si el primer imput es mayor el resultado es positivo, si es menor el resultado es negativo, si se empata utilizamos el ID como segundo criterio.
                else {  // Inicializamos los id's como variables y las comparamos.
                return Integer.compare(ganancia1, ganancia2); 
                }
            }
            else if (criterio == "antiguedad"){
                int timestamp1 = traslado1.timestamp; 
                int timestamp2 = traslado2.timestamp;
                return Integer.compare(timestamp2, timestamp1);
            }
            return 0; //nunca pasa pues las únicas claves posibles son redituabilidad y antiguedad
        }
}