package aed;
import java.util.Comparator;

public class SuperavitCiudades <T> {
    private Tupla[] elems;   
    private int[] posiciones; 

    // Comparador interno para ordenar por superávit y resolver empates por ID.
    private class superavitComparator implements Comparator<Tupla> {
        @Override
        public int compare(Tupla c1, Tupla c2) {
            if (Integer.compare(c1.second, c2.second) == 0) {
                return Integer.compare(c2.first, c1.first); // En caso de empate, prioriza el ID más bajo.
            } else {
                return Integer.compare(c1.second, c2.second); // Ordena por superávit.
            }
        }
    }

    // Constructor del heap.
    public SuperavitCiudades(int cantCiudades) {
        Tupla[] heap = new Tupla[cantCiudades];
        int[] posicionesElems = new int[cantCiudades];
        
        // Vamos agregando.  
        for (int idCiudad = 0; idCiudad < cantCiudades; idCiudad++) {
            heap[idCiudad] = new Tupla(idCiudad, 0); 
            posicionesElems[idCiudad] = idCiudad;
        }
        
        this.elems = heap;
        this.posiciones = posicionesElems;
    }

    // Modifica el superávit de dos ciudades en el heap y ajusta su posición.
    public void modificarHeap(int id1, int id2, int monto) {
        int posicionCiudadOrigen = this.posiciones[id1];
        int posicionCiudadDestino = this.posiciones[id2];
        
        // Actualiza los superávits
        this.elems[posicionCiudadOrigen].second += monto;
        this.elems[posicionCiudadDestino].second -= monto;
        
        // Reubica las ciudades para mantener la propiedad de heap
        heapifyDown(this.elems[this.posiciones[id2]]);
        heapifyUp(this.elems[this.posiciones[id1]]);
    }

    // Restablece la "propiedad" de heap hacia arriba (Osea vamos viendo si son sub-arboles).
    private void heapifyUp(Tupla ciudad) {   
        int hijoActual = posiciones[ciudad.first];
        boolean necesitaIntercambio = true;

        while (hijoActual > 0 && necesitaIntercambio) {
            int padreActual = (hijoActual - 1) / 2;
            superavitComparator comparador = new superavitComparator();
            
            if (comparador.compare(this.elems[hijoActual], this.elems[padreActual]) > 0) {
                // Intercambia posiciones si el hijo es mayor que el padre.
                swap(padreActual, this.elems[padreActual].first, hijoActual, ciudad.first);
                hijoActual = padreActual;
            } else {
                necesitaIntercambio = false; // Si no necesita intercambio, termina el bucle.
            }
        }
    }

    // Restablece la "propiedad"" de heap hacia abajo.
    private void heapifyDown(Tupla ciudad) {
        int indice = posiciones[ciudad.first];
        int tamaño = posiciones.length;

        while (!esHijo(tamaño, indice)) {
            int hijoIzq = 2 * indice + 1;
            int hijoDer = 2 * indice + 2;
            int mayor = hijoIzq; 
            superavitComparator comparador = new superavitComparator();
            
            // Escoge el hijo mayor entre los dos para intercambio.
            if (hijoDer < tamaño && comparador.compare(this.elems[hijoDer], this.elems[hijoIzq]) > 0) {
                mayor = hijoDer;
            }

            // Si el elemento actual es mayor que el hijo más grande, termina el bucle.
            if (comparador.compare(this.elems[indice], this.elems[mayor]) >= 0) {
                break;
            }

            // Intercambia y actualiza el índice.
            swap(indice, this.elems[indice].first, mayor, this.elems[mayor].first);
            indice = mayor;
        }
    }

    // Intercambia dos elementos en el heap y actualiza sus posiciones.

    private void swap(int posPadre, int idPadre, int posHijo, int idHijo) {
        Tupla temp = this.elems[posPadre];
        this.elems[posPadre] = this.elems[posHijo];
        this.elems[posHijo] = temp;
        this.posiciones[idPadre] = posHijo;
        this.posiciones[idHijo] = posPadre;
    }

    // Comprueba si el índice dado representa un nodo sin hijos (es una hoja).
    
    private boolean esHijo(int tamaño, int indice) {  
        return indice > tamaño / 2 - 1;
    }

    // Devuelve el ID de la ciudad con el mayor superávit.
    public int consultarMax(SuperavitCiudades<T> heap) {
        return heap.elems[0].first;
    }
}