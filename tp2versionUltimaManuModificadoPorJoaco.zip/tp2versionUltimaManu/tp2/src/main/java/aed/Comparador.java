package aed;

import java.util.Comparator;

// Comparador adaptable.
public class Comparador implements Comparator<Traslado> {
        private String criterio;


        public Comparador(String pauta){
            criterio = pauta;
            }
        @Override

        public int compare(Traslado traslado1, Traslado traslado2) {
            if (criterio == "redituabilidad"){
                int ganancia1 = traslado1.gananciaNeta; 
                int ganancia2 = traslado2.gananciaNeta;
    
                if (ganancia1 > ganancia2) {         // Si el primer imput es mayor el resultado es 1, si es menor el resultado es -1, si se empata utilizamos el ID como segundo criterio.
                    return 1;
                } 
                else if (ganancia1 < ganancia2) {
                    return -1;
                } 
                else {  // Inicializamos los id's como variables y las comparamos.
                int id1 = traslado1.id;
                int id2 = traslado2.id;
                return Integer.compare(id2, id1); 
                }
            }
            else if (criterio == "antiguedad"){
                int timestamp1 = traslado1.timestamp; 
                int timestamp2 = traslado2.timestamp;
                if (timestamp1 < timestamp2) {         // Si el primer imput es mayor el resultado es 1, si es menor el resultado es -1, si se empata utilizamos el ID como segundo criterio.
                    return 1;
                } 
                else if (timestamp1 > timestamp2) {
                    return -1;
                } ;
            }
            return 0;
        }
}